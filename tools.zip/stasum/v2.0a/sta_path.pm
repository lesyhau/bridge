package STA_Path;
use warnings;
use strict;

# ------------------------------------------------------------------------------
# Constructor
sub New
{
   my $class = shift;
   my $obj = {@_};
   bless($obj, $class);
   return $obj;
}

# ------------------------------------------------------------------------------
# Object accessor methods
sub	StartPoint			{ $_[0]->{StartPoint			}	= $_[1] if defined $_[1]; $_[0]->{StartPoint			}}
sub	StartClock			{ $_[0]->{StartClock			}	= $_[1] if defined $_[1]; $_[0]->{StartClock			}}
sub	EndPoint			{ $_[0]->{EndPoint				}	= $_[1] if defined $_[1]; $_[0]->{EndPoint				}}
sub	EndClock			{ $_[0]->{EndClock				}	= $_[1] if defined $_[1]; $_[0]->{EndClock				}}
sub	PathGroup			{ $_[0]->{PathGroup				}	= $_[1] if defined $_[1]; $_[0]->{PathGroup				}}
sub	PathType			{ $_[0]->{PathType				}	= $_[1] if defined $_[1]; $_[0]->{PathType				}}
sub	InputExternalDelay	{ $_[0]->{InputExternalDelay	}	= $_[1] if defined $_[1]; $_[0]->{InputExternalDelay	}}
sub	OutputExternalDelay	{ $_[0]->{OutputExternalDelay	}	= $_[1] if defined $_[1]; $_[0]->{OutputExternalDelay	}}
sub	DataArrivalTime		{ $_[0]->{DataArrivalTime		}	= $_[1] if defined $_[1]; $_[0]->{DataArrivalTime		}}
sub	DataRequiredTime	{ $_[0]->{DataRequiredTime		}	= $_[1] if defined $_[1]; $_[0]->{DataRequiredTime		}}
sub	SlackTime			{ $_[0]->{SlackTime				}	= $_[1] if defined $_[1]; $_[0]->{SlackTime				}}
sub	Slack				{ $_[0]->{Slack					}	= $_[1] if defined $_[1]; $_[0]->{Slack					}}
sub	FileName			{ $_[0]->{FileName				}	= $_[1] if defined $_[1]; $_[0]->{FileName				}}

# ------------------------------------------------------------------------------
# Print out obj definition
sub	PrintObjDef
{
	my $obj = shift;
	my	$startPoint				=	$obj->StartPoint			;
	my	$startClock				=	$obj->StartClock			;
	my	$endPoint				=	$obj->EndPoint				;
	my	$endClock				=	$obj->EndClock				;
	my	$pathGroup				=	$obj->PathGroup				;
	my	$pathType				=	$obj->PathType				;
	my	$inputExternalDelay		=	$obj->InputExternalDelay	;
	my	$outputExternalDelay	=	$obj->OutputExternalDelay	;
	my	$dataArrivalTime		=	$obj->DataArrivalTime		;
	my	$dataRequiredTime		=	$obj->DataRequiredTime		;
	my	$slackTime				=	$obj->SlackTime				;
	my	$slack					=	$obj->Slack					;
	my	$fileName				=	$obj->FileName				;
	
	print <<EOF
-	\$startPoint			=	$obj->{StartPoint			};
-	\$startClock			=	$obj->{StartClock			};
-	\$endPoint				=	$obj->{EndPoint				};
-	\$endClock				=	$obj->{EndClock				};
-	\$pathGroup				=	$obj->{PathGroup			};
-	\$pathType				=	$obj->{PathType				};
-	\$inputExternalDelay	=	$obj->{InputExternalDelay	};
-	\$outputExternalDelay	=	$obj->{OutputExternalDelay	};
-	\$dataArrivalTime		=	$obj->{DataArrivalTime		};
-	\$dataRequiredTime		=	$obj->{DataRequiredTime		};
-	\$slackTime				=	$obj->{SlackTime			};
-	\$slack					=	$obj->{Slack				};
-	\$fileName				=	$obj->{FileName				};
EOF

}

return 1;
