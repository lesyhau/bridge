package STA_File;

use warnings;
use strict;

use lib "/home/u/haule2/tools/stasum/v2.0a";
use sta_path;

my $toolver = "v2.0a";
my $toolbase = "/home/u/haule2/tools/stasum/$toolver";

my $t_scl = 0;
my $t_sda = 0;
my $t_sda1 = 0;
my $t_scl_found = 0;
my $t_sda_found = 0;
my $t_sda1_found = 0;

my $i2c_log = "/home/u/haule2/sta_sum_i2c.csv";
open I2C_LOG, ">$i2c_log" or die "[Error] Cannot open file $i2c_log. $!\n";

# Paths list
my @Paths;

# ------------------------------------------------------------------------------
# Constructor
sub New
{
   my $class = shift;
   my $obj = {@_};
   bless($obj, $class);
   
   $obj->_ReadSTAFile;
   
   return $obj;
}

# ------------------------------------------------------------------------------
# Object accessor methods
sub	FilePath	{ $_[0]->{FilePath	} = $_[1] if defined $_[1]; $_[0]->{FilePath	} }
sub	Debug		{ $_[0]->{Debug		} = $_[1] if defined $_[1]; $_[0]->{Debug		} }

# ------------------------------------------------------------------------------
# Class accessor methods
sub Paths { @Paths }
sub PathsCount { scalar @Paths }

# ------------------------------------------------------------------------------
# Add path into paths list
sub	_AddPath
{
	my $obj = shift;
	my $path = shift;
	my $debug = $obj->Debug;
	
	push @Paths, $path;
	
	if ($debug == 1)
	{
		print <<EOF
-	DEBUG:	New path has been added into paths list.
-	
EOF
	}
}

# ------------------------------------------------------------------------------
# Read STA file
sub _ReadSTAFile
{
	my $obj = shift;
	my $sta_file = $obj->FilePath;
	my $debug = $obj->Debug;
	my $fileName = `basename $sta_file`; chomp $fileName;
	
	open STA_I2C_LOG, "<$sta_file" or die "ERROR:	$!\n";

	my $path = STA_Path->New
	(
		StartPoint			=> "-",
		StartClock			=> "-",
		EndPoint			=> "-",
		EndClock			=> "-",
		PathGroup			=> "-",
		PathType			=> "-",
		InputExternalDelay	=> "-",
		OutputExternalDelay	=> "-",
		DataArrivalTime		=> "-",
		DataRequiredTime	=> "-",
		SlackTime			=> "-",
		Slack				=> "-",
		FileName			=> "-",
	);
	
	my $start_point_found = 0;
	my $end_point_found = 0;
	my $path_group_found = 0;
	my $path_type_found = 0;
	my $start_clock_found = 0;
	my $input_external_delay_skip = 0;
	my $input_external_delay_found = 0;
	my $output_external_delay_skip = 0;
	my $output_external_delay_found = 0;
	my $end_clock_found = 0;
	my $data_arrival_time_found = 0;
	my $data_required_time_found = 0;
	my $slack_found = 0;

	my $line_pos = 0;
	
	while (<STA_I2C_LOG>)
	{
        $line_pos++;

		# Looks for start point
		if ($start_point_found == 0)
		{
			if ($_ =~ /Startpoint/)
			{
				$path->StartPoint((split (" ", $_))[1]);
				$start_point_found = 1;
				
			    #$start_point_found = 0;
			    $end_point_found = 0;
			    $path_group_found = 0;
			    $path_type_found = 0;
			    $start_clock_found = 0;
			    $input_external_delay_found = 0;
			    $output_external_delay_found = 0;
                $data_arrival_time_found = 0;
			    $end_clock_found = 0;
                $data_required_time_found = 0;
			    $slack_found = 0;

                if ($debug == 1)
				{
                    printf ("\n%-10s %-20s %s\n", "DEBUG", "Start point:", $path->StartPoint);
                    printf ("%-10s %-20s %s\n", "DEBUG", "At line:", $line_pos);
                }

				goto SKIP_LINE;
			}
		}
		
		# Looks for end point
		if (($end_point_found == 0) and ($start_point_found == 1))
		{
			if ($_ =~ /Endpoint/)
			{
				$path->EndPoint((split (" ", $_))[1]);
				$end_point_found = 1;

			    #$start_point_found = 0;
			    #$end_point_found = 0;
			    $path_group_found = 0;
			    $path_type_found = 0;
			    $start_clock_found = 0;
			    $input_external_delay_found = 0;
			    $output_external_delay_found = 0;
                $data_arrival_time_found = 0;
			    $end_clock_found = 0;
                $data_required_time_found = 0;
			    $slack_found = 0;

                if ($debug == 1)
				{
                    printf ("%-10s %-20s %s\n", "DEBUG", "End point:", $path->EndPoint);
                    printf ("%-10s %-20s %s\n", "DEBUG", "At line:", $line_pos);
                }

				goto SKIP_LINE;
			}
		}
		
		# Looks for path group
		if (($path_group_found == 0) and ($end_point_found == 1))
		{
			if ($_ =~ /Path Group/)
			{
				$path->PathGroup((split (" ", $_))[2]);
				$path_group_found = 1;

			    #$start_point_found = 0;
			    #$end_point_found = 0;
			    #$path_group_found = 0;
			    $path_type_found = 0;
			    $start_clock_found = 0;
			    $input_external_delay_found = 0;
			    $output_external_delay_found = 0;
                $data_arrival_time_found = 0;
			    $end_clock_found = 0;
                $data_required_time_found = 0;
			    $slack_found = 0;

                if ($debug == 1)
				{
                    printf ("%-10s %-20s %s\n", "DEBUG", "Path group:", $path->PathGroup);
                    printf ("%-10s %-20s %s\n", "DEBUG", "At line:", $line_pos);
                }

				goto SKIP_LINE;
			}
		}
		
		# Looks for path type
		if (($path_type_found == 0) and ($path_group_found == 1))
		{
			if ($_ =~ /Path Type/)
			{
				$path->PathType((split (" ", $_))[2]);
				$path_type_found = 1;

			    #$start_point_found = 0;
			    #$end_point_found = 0;
			    #$path_group_found = 0;
			    #$path_type_found = 0;
			    $start_clock_found = 0;
			    $input_external_delay_found = 0;
			    $output_external_delay_found = 0;
                $data_arrival_time_found = 0;
			    $end_clock_found = 0;
                $data_required_time_found = 0;
			    $slack_found = 0;

                if ($debug == 1)
				{
                    printf ("%-10s %-20s %s\n", "DEBUG", "Path type:", $path->PathType);
                    printf ("%-10s %-20s %s\n", "DEBUG", "At line:", $line_pos);
                }

				goto SKIP_LINE;
			}
		}
		
		# Looks for start clock
		if (($start_clock_found == 0) and ($path_type_found == 1))
		{
			if ($_ =~ /clock/)
			{
				$path->StartClock((split (" ", $_))[1]);
				$start_clock_found = 1;

			    #$start_point_found = 0;
			    #$end_point_found = 0;
			    #$path_group_found = 0;
			    #$path_type_found = 0;
			    #$start_clock_found = 0;
			    $input_external_delay_found = 0;
			    $output_external_delay_found = 0;
                $data_arrival_time_found = 0;
			    $end_clock_found = 0;
                $data_required_time_found = 0;
			    $slack_found = 0;

                if ($debug == 1)
				{
                    printf ("%-10s %-20s %s\n", "DEBUG", "Start clock:", $path->StartClock);
                    printf ("%-10s %-20s %s\n", "DEBUG", "At line:", $line_pos);
                }

				goto SKIP_LINE;
			}
		}
		
		# Looks for input delay
		# if (($input_external_delay_found == 0) and ($input_external_delay_skip == 0) and ($start_clock_found == 1) and ($output_external_delay_found == 0))
		if (($input_external_delay_found == 0) and ($input_external_delay_skip == 0) and ($start_clock_found == 1))
		{
			if ($_ =~ /input external delay/)
			{
				$path->InputExternalDelay((split (" ", $_))[3]);
				$input_external_delay_found = 1;
				$output_external_delay_skip = 1; # If input external delay found, skip for searching output external delay
                
			    #$start_point_found = 0;
			    #$end_point_found = 0;
			    #$path_group_found = 0;
			    #$path_type_found = 0;
			    #$start_clock_found = 0;
			    #$input_external_delay_found = 0;
                $data_arrival_time_found = 0;
			    $end_clock_found = 0;
			    $output_external_delay_found = 0;
				$data_required_time_found = 0;
			    $slack_found = 0;

                if ($debug == 1)
				{
                    printf ("%-10s %-20s %s\n", "DEBUG", "InExDly:", $path->InputExternalDelay);
                    printf ("%-10s %-20s %s\n", "DEBUG", "At line:", $line_pos);
                }

				goto SKIP_LINE;
			}
		}
		
		# Looks for data arrival time
		if (($data_arrival_time_found == 0) and ($start_clock_found == 1))
		{
			if ($_ =~ /data arrival time/)
			{
				$path->DataArrivalTime((split (" ", $_))[3]);
				$data_arrival_time_found = 1;
				$input_external_delay_skip = 1; # If data arrival time found, skip for searching input external delay
                
			    #$start_point_found = 0;
			    #$end_point_found = 0;
			    #$path_group_found = 0;
			    #$path_type_found = 0;
			    #$start_clock_found = 0;
			    #$data_arrival_time_found = 0;
			    $end_clock_found = 0;
			    $output_external_delay_found = 0;
                $data_required_time_found = 0;
			    $slack_found = 0;

                if ($debug == 1)
				{
                    printf ("%-10s %-20s %s\n", "DEBUG", "DAT:", $path->DataArrivalTime);
                    printf ("%-10s %-20s %s\n", "DEBUG", "At line:", $line_pos);
                }

                goto SKIP_LINE;
			}
		}

		# Looks for end clock
		if (($end_clock_found == 0) and ($data_arrival_time_found == 1))
		{
			if ($_ =~ /clock/)
			{
				$path->EndClock((split (" ", $_))[1]);
				$end_clock_found = 1;

			    #$start_point_found = 0;
			    #$end_point_found = 0;
			    #$path_group_found = 0;
			    #$path_type_found = 0;
			    #$start_clock_found = 0;
			    #$input_external_delay_found = 0;
                #$data_arrival_time_found = 0;
			    #$end_clock_found = 0;
			    $output_external_delay_found = 0;
                $data_required_time_found = 0;
			    $slack_found = 0;

                if ($debug == 1)
				{
                    printf ("%-10s %-20s %s\n", "DEBUG", "End clock:", $path->EndClock);
                    printf ("%-10s %-20s %s\n", "DEBUG", "At line:", $line_pos);
                }

				goto SKIP_LINE;
			}
		}

		# Looks for output delay
		if (($output_external_delay_found == 0) and ($output_external_delay_skip == 0) and ($end_clock_found == 1))
		{
			if ($_ =~ /output external delay/)
			{
				$path->OutputExternalDelay((split (" ", $_))[3]);
				$output_external_delay_found = 1;

			    #$start_point_found = 0;
			    #$end_point_found = 0;
			    #$path_group_found = 0;
			    #$path_type_found = 0;
			    #$start_clock_found = 0;
			    #$input_external_delay_found = 0;
                #$data_arrival_time_found = 0;
			    #$end_clock_found = 0;
			    #$output_external_delay_found = 0;
                $data_required_time_found = 0;
			    $slack_found = 0;

                if ($debug == 1)
				{
                    printf ("%-10s %-20s %s\n", "DEBUG", "OutExDly:", $path->OutputExternalDelay);
                    printf ("%-10s %-20s %s\n", "DEBUG", "At line:", $line_pos);
                }

				goto SKIP_LINE;
			}
		}
			
		# Looks for data required time
		if (($data_required_time_found == 0) and ($end_clock_found == 1))
		{
			if ($_ =~ /data required time/)
			{
				$path->DataRequiredTime((split (" ", $_))[3]);
				$data_required_time_found = 1;

			    #$start_point_found = 0;
			    #$end_point_found = 0;
			    #$path_group_found = 0;
			    #$path_type_found = 0;
			    #$start_clock_found = 0;
			    #$input_external_delay_found = 0;
                #$data_arrival_time_found = 0;
			    #$end_clock_found = 0;
			    #$output_external_delay_found = 0;
                #$data_required_time_found = 0;
			    $slack_found = 0;

                if ($debug == 1)
				{
                    printf ("%-10s %-20s %s\n", "DEBUG", "DRT:", $path->DataRequiredTime);
                    printf ("%-10s %-20s %s\n", "DEBUG", "At line:", $line_pos);
                }

                goto SKIP_LINE;
			}
		}

		# Looks for slack
		if (($slack_found == 0) and ($data_required_time_found == 1))
		{
			if ($_ =~ /slack/)
			{
				my @words = split (" ", $_);
				$path->Slack($words[1]);
				$path->Slack(substr $path->Slack, 1);
				$path->Slack(substr $path->Slack, 0, -1);
				$path->SlackTime($words[2]); 
				$slack_found = 1;

			    #$start_point_found = 0;
			    #$end_point_found = 0;
			    #$path_group_found = 0;
			    #$path_type_found = 0;
			    #$start_clock_found = 0;
			    #$input_external_delay_found = 0;
                #$data_arrival_time_found = 0;
			    #$end_clock_found = 0;
			    #$output_external_delay_found = 0;
                #$data_required_time_found = 0;
			    #$slack_found = 0;

                if ($debug == 1)
				{
                    printf ("%-10s %-20s %s\n", "DEBUG", "Slack:", $path->Slack);
                    printf ("%-10s %-20s %s\n", "DEBUG", "At line:", $line_pos);
                }

				$path->FileName($fileName);

			}
		}
		
		if ($slack_found == 1)
		{
			$obj->_AddPath($path);

            if ($path->FileName =~ /INopen/)
            {
                if ($t_scl_found == 0)
                {
                    if ($path->EndPoint =~ /cf_meta/)
                    {
                        $t_scl = $path->DataArrivalTime;
                        $t_scl_found = 1;
                        print I2C_LOG "$path->{StartPoint}, $path->{EndPoint}, ";
                    }
                }

                if ($t_sda_found == 0)
                {
                    if ($path->EndPoint =~ /df_meta/)
                    {
                        $t_sda = $path->DataArrivalTime;
                        $t_sda_found = 1;
                        print I2C_LOG "$path->{StartPoint}, $path->{EndPoint}, ";
                    }
                }
		
                if (($t_scl_found == 1) and ($t_sda_found == 1))
                {
                    my $delta = $t_scl - $t_sda;
                    print I2C_LOG ",,,,$delta, ";

                    if (($delta > 5) or ($delta < -5)) { print I2C_LOG "VIOLATED, "; }
                    else { print I2C_LOG "MET, "; }

                    print I2C_LOG "INopen\n";

                    $t_scl_found = 0;
                    $t_sda_found = 0;
                }
            }
            elsif ($path->FileName =~ /OUTopen/)
            {
                if ($t_scl_found == 0)
                {
                    if ($path->StartPoint =~ /scl_op/)
                    {
                        $t_scl = $path->DataArrivalTime;
                        $t_scl_found = 1;
                        print I2C_LOG "$path->{StartPoint}, $path->{EndPoint}, ";
                    }
                }

                if ($t_sda_found == 0)
                {
                    if ($path->StartPoint =~ /sda_op/)
                    {
                        $t_sda = $path->DataArrivalTime;
                        $t_sda_found = 1;
                        print I2C_LOG "$path->{StartPoint}, $path->{EndPoint}, ";
                    }
                }
		
                elsif ($t_sda1_found == 0)
                {
                    if ($path->StartPoint =~ /sda_op/)
                    {
                        $t_sda1 = $path->DataArrivalTime;
                        $t_sda1_found = 1;
                        print I2C_LOG "$path->{StartPoint}, $path->{EndPoint}, ";
                    }
                }
		
                if (($t_scl_found == 1) and ($t_sda_found == 1) and ($t_sda1_found == 1))
                {
                    my $delta = $t_scl - $t_sda;
                    print I2C_LOG "$delta, ";

                    if (($delta > 5) or ($delta < -5)) { print I2C_LOG "VIOLATED, "; }
                    else { print I2C_LOG "MET, "; }

                    $delta = $t_scl - $t_sda1;
                    print I2C_LOG "$delta, ";

                    if (($delta > 5) or ($delta < -5)) { print I2C_LOG "VIOLATED, "; }
                    else { print I2C_LOG "MET, "; }

                    print I2C_LOG "OUTopen\n";

                    $t_scl_found = 0;
                    $t_sda_found = 0;
                    $t_sda1_found = 0;
                }
            }

			if ($debug == 1)
			{
				print $path->StartPoint				, ",";
				print $path->StartClock				, ",";
				print $path->EndPoint				, ",";
				print $path->EndClock				, ",";
				print $path->PathGroup				, ",";
				print $path->PathType				, ",";
				print $path->InputExternalDelay		, ",";
				print $path->OutputExternalDelay	, ",";
				print $path->DataArrivalTime		, ",";
				print $path->DataRequiredTime		, ",";
				print $path->SlackTime				, ",";
				print $path->Slack					, ",";
				print $path->FileName				, ",";
				print "\n";
			}
			
			# Reset path properties
			$path = STA_Path->New
			(
				StartPoint			=> "-",
				StartClock			=> "-",
				EndPoint			=> "-",
				EndClock			=> "-",
				PathGroup			=> "-",
				PathType			=> "-",
				InputExternalDelay	=> "-",
				OutputExternalDelay	=> "-",
				DataArrivalTime		=> "-",
				DataRequiredTime	=> "-",
				SlackTime			=> "-",
				Slack				=> "-",
				FileName			=> "-",
			);
			
			# Reset flags
			$start_point_found = 0;
			$end_point_found = 0;
			$path_group_found = 0;
			$path_type_found = 0;
			$start_clock_found = 0;
			$input_external_delay_found = 0;
			$output_external_delay_found = 0;
			$input_external_delay_skip = 0;
			$output_external_delay_skip = 0;
            $data_arrival_time_found = 0;
			$end_clock_found = 0;
            $data_required_time_found = 0;
			$slack_found = 0;
		}
		
		SKIP_LINE:
	}
}

return 1;
