
/* Standard library */
#include <stdint.h>

/* R-Car Gen 3 I2C library */
#include "i2c.h"
#include "i2c_v3u.h"

/* Simulation utilities */
#include <sim_utils.h>

void checkReg(volatile uint32_t * addr)
{
    *addr = 0xffffffff;
    Sim_Dump(*addr);

    *addr = 0xa5a5a5a5;
    Sim_Dump(*addr);

    *addr = 0x5a5a5a5a;
    Sim_Dump(*addr);

    *addr = 0x00000000;
    Sim_Dump(*addr);
}

int main(void)
{
    checkReg(&I2C0->ICSCR);
    checkReg(&I2C0->ICMCR);
    checkReg(&I2C0->ICSSR);
    checkReg(&I2C0->ICMSR);
    checkReg(&I2C0->ICSIER);
    checkReg(&I2C0->ICMIER);
    checkReg(&I2C0->ICCCR);
    checkReg(&I2C0->ICSAR);
    checkReg(&I2C0->ICMAR);
    checkReg(&I2C0->ICRXD);
    checkReg(&I2C0->ICCCR2);
    checkReg(&I2C0->ICMPR);
    checkReg(&I2C0->ICHPR);
    checkReg(&I2C0->ICLPR);
    checkReg(&I2C0->ICFBSCR);
    checkReg(&I2C0->ICDMAER);

    Sim_Dump(0x12345678);
	Sim_Stop();

    while(1);

    return (0);
}

/******************************************************************************
 *
 * Exception handlers
 *
 ****************************************************************************/

void Default_Handler                 (void) __attribute__((weak));
void UndefinedInstruction_Handler    (void) __attribute__((weak, alias("Default_Handler")));
void SupervisorCall_Handler          (void) __attribute__((weak, alias("Default_Handler")));
void PrefetchAbort_Handler           (void) __attribute__((weak, alias("Default_Handler")));
void DataAbort_Handler               (void) __attribute__((weak, alias("Default_Handler")));
void IRQ_Handler                     (void) __attribute__((weak, alias("Default_Handler")));
void FIQ_Handler                     (void) __attribute__((weak, alias("Default_Handler")));

void Default_Handler(void)
{
    /* Infinity loop */
    while(1);
}

