
/* Standard libraries */
#include    <stdint.h>

#include    "cpg.h"

void CPG_SetBit(volatile uint32_t *reg, uint8_t bitPos)
{
	uint32_t data = 1 << bitPos;
	*CPGWPR = ~data;
	*reg |= data;
}

void CPG_ClearBit(volatile uint32_t *reg, uint8_t bitPos)
{
	uint32_t data = 1 << bitPos;
	*CPGWPR = data;
	*reg &= ~data;
}

void CPG_WriteAnd(volatile uint32_t *reg, uint32_t data)
{
	*CPGWPR = ~data;
	*reg &= data;
}

void CPG_WriteOr(volatile uint32_t *reg, uint32_t data)
{
	*CPGWPR = ~data;
	*reg |= data;
}
