
/* Standard library */
#include <stdint.h>

/* R-Car Gen 3 I2C library */
#include "i2c.h"
#include "i2c_v3u.h"
#include "pfc.h"

/* Simulation utilities */
#include "sim_utils.h"

const I2C_MasterConfig_t i2c0MasterConfig =
{
    MASTER_TX,
    I2C1_SLAVE_ADDR,
    START_BYTE_TRANSMIT_DISABLE,
    OD_BUFFER,
    FIXED_DUTY_CYCLE,
    CLOCK_RATE_400KHZ
};

const I2C_SlaveConfig_t i2c1SlaveConfig =
{
    I2C1_SLAVE_ADDR,
    CLOCK_STRETCH_AFTER,
    GENERAL_CALL_ACK_DISABLE,
    OD_BUFFER,
    FIXED_DUTY_CYCLE,
    CLOCK_RATE_400KHZ
};

void configLSIPins(void)
{
    /* Disable I2C bus model */
    __asm(
    "ldr    r10, = 0x5aa55aa5"
    );

//    /* Config I2C0 LSI pins */
//    PFC_SetBit(MOD_SEL2, 29);
//
//    /* Config I2C1 LSI pins */
//    PFC_ClearBit(MOD_SEL0, 20);
//    PFC_WriteAnd(IPSR13, 0xffffff44);
//    PFC_WriteOr(IPSR13, 0x00000044);
//    PFC_WriteOr(GPSR5, 0x00000C00);

    /* Enable I2C bus model */
    __asm(
    "ldr    r10, = 0"
    );
}

int main(void)
{
    uint32_t receivedData[2];

    /**************************************************************************
     * Modules configuration
     *************************************************************************/

    /* Configure I2C's LSI pins */
    configLSIPins();

    /* Configure I2C0 in master TX mode */
    I2C_masterInit(I2C0, &i2c0MasterConfig);
    I2C_masterClearInterruptStatus(I2C0, (~0));
    I2C_masterEnable(I2C0);

    /* Configure I2C1 in slave RX mode */
    I2C_slaveInit(I2C1, &i2c1SlaveConfig);
    I2C_slaveClearInterruptStatus(I2C1, (~0));
    I2C_slaveEnable(I2C1);

    /**************************************************************************
     * Slave address transmition
     *************************************************************************/

    /* Set the first data byte, send start condition, send slave address */
    I2C_masterSendMultipleByteStart(I2C0, 0xaa);

    /* Wait for SAR */
    while (! I2C1->SAR);
    I2C_slaveClearInterruptStatus(I2C1, SAR_MASK);

    /* Wait for MAT */
    /* Note: At this moment, MDE is also set, it is also need to be cleared */
    while (! I2C0->MAT);
    I2C_masterClearInterruptStatus(I2C0, MAT_MASK | MDE_MASK);

    /* Clear ESG */
    I2C0->ESG = 0;

    /**************************************************************************
     * The first data byte transmition
     *************************************************************************/

    /* Wait for MDE */
    while (! I2C0->MDE);
    /* Clear ESG end then set the next data byte */
    I2C_masterSendMultipleByteNext(I2C0, 0x55);
    I2C_masterClearInterruptStatus(I2C0, MDE_MASK);

    /* Wait for SDR */
    while (! I2C1->SDR);
    I2C_slaveClearInterruptStatus(I2C1, SDR_MASK);

    /* Get the first data byte, send NACK after received the next data byte */
    receivedData[0] = I2C_slaveReceiveMultipleByteStop(I2C1);

    /* Wait for MDT */
    while (! I2C0->MDT);
    I2C_masterClearInterruptStatus(I2C0, MDT_MASK);

    /**************************************************************************
     * The second data byte transmition
     *************************************************************************/

    /* Wait for MDE */
    while (! I2C0->MDE);
    I2C_masterClearInterruptStatus(I2C0, MDE_MASK);

    /* Wait for SDR */
    while (! I2C1->SDR);
    I2C_slaveClearInterruptStatus(I2C1, SDR_MASK);

    /* Get the second data byte */
    receivedData[1] = I2C_slaveReceiveMultipleByteFinish(I2C1);

    /* Wait for MDT */
    while (! I2C0->MDT);
    I2C_masterClearInterruptStatus(I2C0, MDT_MASK);

    /**************************************************************************
     * The end of the current transmition
     *************************************************************************/

    /* Wait for MDE */
    while (! I2C0->MDE);
    I2C_masterClearInterruptStatus(I2C0, MDE_MASK);

    /* Wait for MNR */
    while (! I2C0->MNR);
    I2C_masterClearInterruptStatus(I2C0, MNR_MASK);

    /* Wait for SSR */
    while (! I2C1->SSR);
    I2C_slaveClearInterruptStatus(I2C1, SSR_MASK);

    /* Wait for MST */
    while (! I2C0->MST);
    I2C_masterClearInterruptStatus(I2C0, MST_MASK);

    /**************************************************************************
     * The end of the simulation
     *************************************************************************/

    Sim_Dump(receivedData[0]);
    Sim_Dump(receivedData[1]);
    Sim_Dump(0x12345678);
    Sim_Dump(0x12345678);
	Sim_Stop();

    while(1);

    return (0);
}

/******************************************************************************
 *
 * Exception handlers
 *
 ****************************************************************************/

void Default_Handler                 (void) __attribute__((weak));
void UndefinedInstruction_Handler    (void) __attribute__((weak, alias("Default_Handler")));
void SupervisorCall_Handler          (void) __attribute__((weak, alias("Default_Handler")));
void PrefetchAbort_Handler           (void) __attribute__((weak, alias("Default_Handler")));
void DataAbort_Handler               (void) __attribute__((weak, alias("Default_Handler")));
void IRQ_Handler                     (void) __attribute__((weak, alias("Default_Handler")));
void FIQ_Handler                     (void) __attribute__((weak, alias("Default_Handler")));

void Default_Handler(void)
{
    /* Infinity loop */
    while(1);
}

