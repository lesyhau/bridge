
/******************************************************************************
 *
 * I2C definition and library.
 * 
 * 2082 - Hau Sy Le - hau.le.eb@renesas.com
 *
 ****************************************************************************/

#ifndef I2C_H_
#define I2C_H_

/* Standard C libraries */
#include <stdint.h>

#define __W     volatile
#define __R     volatile const
#define __RW    volatile

/* I2C registers */
typedef struct
{
    /* Slave control register. Offset = 0x00 */
    union
    {
        __RW        uint32_t    ICSCR;
        struct
        {
            __RW    uint32_t    FNA     : 1;
            __RW    uint32_t    GCAE    : 1;
            __RW    uint32_t    SIE     : 1;
            __RW    uint32_t    SDBS    : 1;
            __R     uint32_t    ICSCR_RESERVED4 : 1;
            __R     uint32_t    ICSCR_RESERVED5 : 1;
            __R     uint32_t    ICSCR_RESERVED6 : 1;
            __RW    uint32_t    SCSS    : 1;
        };
    };

    /* Master control register. Offset = 0x04 */
    union
    {
        __RW        uint32_t    ICMCR;
        struct
        {
            __RW    uint32_t    ESG     : 1;    // Bit 0
            __RW    uint32_t    FSB     : 1;    // Bit 1
            __RW    uint32_t    TSBI    : 1;    // Bit 2
            __RW    uint32_t    MIE     : 1;    // Bit 3
            __RW    uint32_t    OBPC    : 1;    // Bit 4
            __RW    uint32_t    FSDA    : 1;    // Bit 5
            __RW    uint32_t    FSCL    : 1;    // Bit 6
            __RW    uint32_t    MDBS    : 1;    // Bit 7
        };
    };

    /* Slave status register. Offset = 0x08 */
    union
    {
        __RW        uint32_t    ICSSR;
        struct
        {
            __RW    uint32_t    SAR     : 1;    // Bit 0
            __RW    uint32_t    SDR     : 1;    // Bit 1
            __RW    uint32_t    SDT     : 1;    // Bit 2
            __RW    uint32_t    SDE     : 1;    // Bit 3
            __RW    uint32_t    SSR     : 1;    // Bit 4
            __R     uint32_t    SSTM    : 1;    // Bit 5
            __RW    uint32_t    GCAR    : 1;    // Bit 6
        };
    };
    
    /* Master status register. Offset = 0x0c */
    union
    {
        __RW        uint32_t    ICMSR;
        struct
        {
            __RW    uint32_t    MAT     : 1;    // Bit 0
            __RW    uint32_t    MDR     : 1;    // Bit 1
            __RW    uint32_t    MDT     : 1;    // Bit 2
            __RW    uint32_t    MDE     : 1;    // Bit 3
            __RW    uint32_t    MST     : 1;    // Bit 4
            __RW    uint32_t    MAL     : 1;    // Bit 5
            __RW    uint32_t    MNR     : 1;    // Bit 6
        };
    };

    /* Slave interrupt enable register. Offset = 0x10 */
    union
    {
        __RW        uint32_t    ICSIER;
        struct
        {
            __RW    uint32_t    SARE    : 1;    // Bit 0
            __RW    uint32_t    SDRE    : 1;    // Bit 1
            __RW    uint32_t    SDTE    : 1;    // Bit 2
            __RW    uint32_t    SDEE    : 1;    // Bit 3
            __RW    uint32_t    SSRE    : 1;    // Bit 4
        };
    };

    /* Master interrupt enable register. Offset = 0x14 */
    union
    {
        __RW        uint32_t    ICMIER;
        struct
        {
            __RW    uint32_t    MATE    : 1;    // Bit 0
            __RW    uint32_t    MDRE    : 1;    // Bit 1
            __RW    uint32_t    MDTE    : 1;    // Bit 2
            __RW    uint32_t    MDEE    : 1;    // Bit 3
            __RW    uint32_t    MSTE    : 1;    // Bit 4
            __RW    uint32_t    MALE    : 1;    // Bit 5
            __RW    uint32_t    MNRE    : 1;    // Bit 6
        };
    };

    /* Clock control register. Offset = 0x18 */
    union
    {
        __RW        uint32_t    ICCCR;
        struct
        {
            __RW    uint32_t    CDF     : 3;    // Bit 0:2
            __RW    uint32_t    SCGD    : 6;    // Bit 3:8
        };
    };

    /* Slave address register. Offset = 0x1c */
    union
    {
        __RW        uint32_t    ICSAR;
        struct
        {
            __RW    uint32_t    SADD0   : 7;    // Bit 0:6
        };
    };
    
    /* Master address register. Offset = 0x20 */
    union
    {
        __RW        uint32_t    ICMAR;
        struct
        {
            __RW    uint32_t    STM     : 1;    // Bit 0
            __RW    uint32_t    SADD1   : 7;    // Bit 1:7
        };
    };

    /* Transmit/receive data register. Offset = 0x24 */
    union
    {
        __R         uint32_t    ICRXD;
        __W         uint32_t    ICTXD;
        struct
        {
            __R     uint8_t     RXD;            // Bit 0:7
        };
        struct
        {
            __W     uint8_t     TXD;            // Bit 0:7
        };
    };

    /* Clock control register 2. Offset = 0x28 */
    union
    {
        __RW        uint32_t    ICCCR2;
        struct
        {
            __RW    uint32_t    SME     : 1;    // Bit 0
            __RW    uint32_t    HLSE    : 1;    // Bit 1
            __RW    uint32_t    CDFD    : 1;    // Bit 2
        };
    };

    /* SCL mask control register. Offset = 0x2c */
    union
    {
        __RW        uint32_t    ICMPR;
        struct
        {
            __RW    uint8_t     SMD;            // Bit 0:7
        };
    };

    /* SCL high control register. Offset = 0x30 */
    union
    {
        __RW        uint32_t    ICHPR;
        struct
        {
            __RW    uint16_t    SCHD;           // Bit 0:15
        };
    };

    /* SCL low control register. Offset = 0x34 */
    union
    {
        __RW        uint32_t    ICLPR;
        struct
        {
            __RW    uint16_t    SCLD;           // Bit 0:15
        };
    };

    /* Fist bit setup cycle register. Offset = 0x38 */
    union
    {
        __RW        uint32_t    ICFBSCR;
        struct
        {
            __RW    uint32_t    FBSC    : 5;    // Bit 0:4
        };
    };

    /* DMA enable register. Offset = 0x3c */
    union
    {
        __RW    uint32_t        ICDMAER;
        struct
        {
            __RW    uint32_t    TMDMAE  : 1;    // Bit 0
            __RW    uint32_t    RMDMAE  : 1;    // Bit 1
            __RW    uint32_t    TSDMAE  : 1;    // Bit 2
            __RW    uint32_t    RSDMAE  : 1;    // Bit 3
            __R     uint32_t    ICDMAER_RESERVED5  : 1;    // Bit 4
            __R     uint32_t    ICDMAER_RESERVED6  : 1;    // Bit 5
            __RW    uint32_t    RMDMAC  : 1;    // Bit 6
            __RW    uint32_t    TMDMAC  : 1;    // Bit 7
            __RW    uint8_t     TMDMATSZ;       // Bit 8:15
            __RW    uint8_t     RMDMATSZ;       // Bit 16:23
            __RW    uint8_t     MDMACTSZ;       // Bit 24:32
        };
    };

} I2C_t;

#define FNA_POS         0
#define GCAE_POS        1
#define SIE_POS         2
#define SDBS_POS        3
#define SCSS_POS        7
#define SAR_POS         0
#define SDR_POS         1
#define SDT_POS         2
#define SDE_POS         3
#define SSR_POS         4
#define STM_POS         5
#define GCAR_POS        6
#define SARE_POS        0
#define SDRE_POS        1
#define SDTE_POS        2
#define SDEE_POS        3
#define SSRE_POS        4
#define SADD0_POS       0
#define SADD1_POS       1
#define ESG_POS         0
#define FSB_POS         1
#define TSBE_POS        2
#define MIE_POS         3
#define OBPC_POS        4
#define FSDA_POS        5
#define FSCL_POS        6
#define MDBS_POS        7
#define MAT_POS         0
#define MDR_POS         1
#define MDT_POS         2
#define MDE_POS         3
#define MST_POS         4
#define MAL_POS         5
#define MNR_POS         6
#define MATE_POS        0
#define MDRE_POS        1
#define MDTE_POS        2
#define MDEE_POS        3
#define MSTE_POS        4
#define MALE_POS        5
#define MNRE_POS        6
#define STM1_POS        0
#define CDF_POS         0
#define SCGD_POS        3
#define SME_POS         0
#define HLSE_POS        1
#define CDFD_POS        2
#define TMDMAE_POS      0
#define RMDMAE_POS      1
#define TSDMAE_POS      2
#define RSDMAE_POS      3
#define RMDMAC_POS      6
#define TMDMAC_POS      7
#define TMDMATSZ_POS    8
#define RMDMATSZ_POS    16
#define MDMACTSZ_POS    24

#define FNA_MASK             (1 << FNA_POS   )
#define GCAE_MASK            (1 << GCAE_POS  )
#define SIE_MASK             (1 << SIE_POS   )
#define SDBS_MASK            (1 << SDBS_POS  )
#define SCSS_MASK            (1 << SCSS_POS  )
#define SAR_MASK             (1 << SAR_POS   )
#define SDR_MASK             (1 << SDR_POS   )
#define SDT_MASK             (1 << SDT_POS   )
#define SDE_MASK             (1 << SDE_POS   )
#define SSR_MASK             (1 << SSR_POS   )
#define STM_MASK             (1 << STM_POS   )
#define GCAR_MASK            (1 << GCAR_POS  )
#define SARE_MASK            (1 << SARE_POS  )
#define SDRE_MASK            (1 << SDRE_POS  )
#define SDTE_MASK            (1 << SDTE_POS  )
#define SDEE_MASK            (1 << SDEE_POS  )
#define SSRE_MASK            (1 << SSRE_POS  )
#define SADD0_MASK           (1 << SADD0_POS )
#define SADD1_MASK           (1 << SADD1_POS )
#define ESG_MASK             (1 << ESG_POS   )
#define FSB_MASK             (1 << FSB_POS   )
#define TSBE_MASK            (1 << TSBE_POS  )
#define MIE_MASK             (1 << MIE_POS   )
#define OBPC_MASK            (1 << OBPC_POS  )
#define FSDA_MASK            (1 << FSDA_POS  )
#define FSCL_MASK            (1 << FSCL_POS  )
#define MDBS_MASK            (1 << MDBS_POS  )
#define MAT_MASK             (1 << MAT_POS   )
#define MDR_MASK             (1 << MDR_POS   )
#define MDT_MASK             (1 << MDT_POS   )
#define MDE_MASK             (1 << MDE_POS   )
#define MST_MASK             (1 << MST_POS   )
#define MAL_MASK             (1 << MAL_POS   )
#define MNR_MASK             (1 << MNR_POS   )
#define MATE_MASK            (1 << MATE_POS  )
#define MDRE_MASK            (1 << MDRE_POS  )
#define MDTE_MASK            (1 << MDTE_POS  )
#define MDEE_MASK            (1 << MDEE_POS  )
#define MSTE_MASK            (1 << MSTE_POS  )
#define MALE_MASK            (1 << MALE_POS  )
#define MNRE_MASK            (1 << MNRE_POS  )
#define STM1_MASK            (1 << STM1_POS  )
#define SME_MASK             (1 << SME_POS   )
#define HLSE_MASK            (1 << HLSE_POS  )
#define CDFD_MASK            (1 << CDFD_POS  )
#define TMDMAE_MASK          (1 << TMDMAE_POS)
#define RMDMAE_MASK          (1 << RMDMAE_POS)
#define TSDMAE_MASK          (1 << TSDMAE_POS)
#define RSDMAE_MASK          (1 << RSDMAE_POS)
#define RMDMAC_MASK          (1 << RMDMAC_POS)
#define TMDMAC_MASK          (1 << TMDMAC_POS)
#define CDF_MASK        0x00000003
#define SCGD_MASK       0x000001f8
#define TMDMATSZ_MASK   0x0000ff00
#define RMDMATSZ_MASK   0x00ff0000
#define MDMACTSZ_MASK   0xff000000

typedef enum
{
    OD_BUFFER,
    LVTTL_BUFFER

} I2C_IOBufferType_t;

typedef enum
{
    FIXED_DUTY_CYCLE,
    VARIABLE_DUTY_CYCLE

} I2C_ClockType_t;

typedef enum
{
    GENERAL_CALL_ACK_DISABLE,
    GENERAL_CALL_ACK_ENABLE

} I2C_GenCallMode_t;

typedef enum
{
    CLOCK_STRETCH_BEFORE,
    CLOCK_STRETCH_AFTER

} I2C_ClockStretchMode_t;

typedef enum
{
    CLOCK_RATE_100KHZ,
    CLOCK_RATE_400KHZ,
    CLOCK_RATE_1MHZ

} I2C_ClockRate_t;

typedef enum
{
    SLAVE_DMA_DISABLE,
    SLAVE_RX_DMA_ENABLE,
    SLAVE_TX_DMA_ENABLE

} I2C_SlaveDMATransferMode_t;

typedef enum
{
    MASTER_TX,
    MASTER_RX

} I2C_MasterTransferMode_t;

typedef enum
{
    START_BYTE_TRANSMIT_DISABLE,
    START_BYTE_TRANSMIT_ENABLE

} I2C_MasterStartByteTransmitMode_t;

typedef enum
{
    MASTER_DMA_DISABLE,
    MASTER_RX_DMA_ENABLE,
    MASTER_TX_DMA_ENABLE

} I2C_MasterDMATransferMode_t;

typedef struct
{
    uint8_t                             SlaveAddress;           // ICSAR
    I2C_ClockStretchMode_t              ClockStretchMode;       // ICSCR.SCSS
    I2C_GenCallMode_t                   GenCallMode;            // ICSCR.GCAE
    I2C_IOBufferType_t                  IOBufferType;           //
    I2C_ClockType_t                     ClockType;              // ICCCR2
    I2C_ClockRate_t                     ClockRate;              // ICCCR, ICCCR2, ICMPR, ICHPR, ICLPR, ICFBSCR
    
} I2C_SlaveConfig_t;

typedef struct
{
    I2C_MasterTransferMode_t            TransferMode;           // ICMAR
    uint8_t                             SlaveAddress;           // ICMAR
    I2C_MasterStartByteTransmitMode_t   StartByteTransmitMode;  // ICMCR
    I2C_IOBufferType_t                  IOBufferType;           //
    I2C_ClockType_t                     ClockType;              // ICCCR2
    I2C_ClockRate_t                     ClockRate;              // ICCCR, ICCCR2, ICMPR, ICHPR, ICLPR, ICFBSCR

} I2C_MasterConfig_t;

extern void I2C_slaveInit(I2C_t *i2c, const I2C_SlaveConfig_t *slaveConfig);
extern void I2C_slaveEnable(I2C_t *i2c);
extern void I2C_slaveDisable(I2C_t *i2c);
extern void I2C_slaveEnableInterrupt(I2C_t *i2c, uint32_t flag);
extern void I2C_slaveDisableInterrupt(I2C_t *i2c, uint32_t flag);
extern uint32_t I2C_slaveGetInterruptStatus(I2C_t *i2c);
extern void I2C_slaveClearInterruptStatus(I2C_t *i2c, uint32_t flag);
extern void I2C_slaveForceNAK(I2C_t *i2c);
extern uint32_t I2C_slaveReceiveMultipleByteNext(I2C_t *i2c);
extern uint32_t I2C_slaveReceiveMultipleByteStop(I2C_t *i2c);
extern uint32_t I2C_slaveReceiveMultipleByteFinish(I2C_t *i2c);
extern void I2C_slaveEnableDMAReceive(I2C_t *i2c);
extern void I2C_slaveDisableDMAReceive(I2C_t *i2c);
extern void I2C_slaveEnableDMATransmit(I2C_t *i2c);
extern void I2C_slaveDisableDMATransmit(I2C_t *i2c);

extern void I2C_masterInit(I2C_t *i2c, const I2C_MasterConfig_t *masterConfig);
extern void I2C_masterEnable(I2C_t *i2c);
extern void I2C_masterDisable(I2C_t *i2c);
extern void I2C_masterEnableInterrupt(I2C_t *i2c, uint32_t flag);
extern void I2C_masterDisableInterrupt(I2C_t *i2c, uint32_t flag);
extern uint32_t I2C_masterGetInterruptStatus(I2C_t *i2c);
extern void I2C_masterClearInterruptStatus(I2C_t *i2c, uint32_t flag);
extern void I2C_masterForceStop(I2C_t *i2c);
extern void I2C_masterSendMultipleByteStart(I2C_t *i2c, uint32_t data);
extern void I2C_masterSendMultipleByteNext(I2C_t *i2c, uint32_t data);
extern void I2C_masterSendMultipleByteStop(I2C_t *i2c, uint32_t data);
extern void I2C_masterSetDMAContinuousTransferCount(I2C_t *i2c, uint8_t transferCount);
extern void I2C_masterSetDMAContinuousReceiveBlockCount(I2C_t *i2c, uint8_t blockCount);
extern void I2C_masterSetDMAContinuousTransmitBlockCount(I2C_t *i2c, uint8_t blockCount);
extern void I2C_masterEnableDMAContinuousReceive(I2C_t *i2c);
extern void I2C_masterDisableDMAContinuousReceive(I2C_t *i2c);
extern void I2C_masterEnableDMAContinuousTransmit(I2C_t *i2c);
extern void I2C_masterDisableDMAContinuousTransmit(I2C_t *i2c);
extern void I2C_masterEnableDMAReceive(I2C_t *i2c);
extern void I2C_masterDisableDMAReceive(I2C_t *i2c);
extern void I2C_masterEnableDMATransmit(I2C_t *i2c);
extern void I2C_masterDisableDMATransmit(I2C_t *i2c);

#endif
