
#ifndef I2C_V3U_H_
#define I2C_V3U_H_

/* Standard C libraries */
#include <stdint.h>

/* I2C driver */
#include "i2c.h"

/* I2C channels base address in V3U */
#define I2C0_BASE_ADDR  0xe6500000
#define I2C1_BASE_ADDR  0xe6508000
#define I2C2_BASE_ADDR  0xe6510000
#define I2C3_BASE_ADDR  0xe66d0000
#define I2C4_BASE_ADDR  0xe66d8000
#define I2C5_BASE_ADDR  0xe66e0000
#define I2C6_BASE_ADDR  0xe66e8000

/* I2C channel objects */
#define I2C0    ((I2C_t *) I2C0_BASE_ADDR)
#define I2C1    ((I2C_t *) I2C1_BASE_ADDR)
#define I2C2    ((I2C_t *) I2C2_BASE_ADDR)
#define I2C3    ((I2C_t *) I2C3_BASE_ADDR)
#define I2C4    ((I2C_t *) I2C4_BASE_ADDR)
#define I2C5    ((I2C_t *) I2C5_BASE_ADDR)
#define I2C6    ((I2C_t *) I2C6_BASE_ADDR)

/* I2C address in slave mode for testing only */
#define I2C0_SLAVE_ADDR 0x50
#define I2C1_SLAVE_ADDR 0x51
#define I2C2_SLAVE_ADDR 0x52
#define I2C3_SLAVE_ADDR 0x53
#define I2C4_SLAVE_ADDR 0x54
#define I2C5_SLAVE_ADDR 0x55
#define I2C6_SLAVE_ADDR 0x56

#endif
