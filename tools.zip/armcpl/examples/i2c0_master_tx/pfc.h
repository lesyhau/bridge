
#ifndef PFC_H_
#define PFC_H_

/* Standard libraries */
#include	<stdint.h>

/* PFC registers */
#define	PMMR		(volatile uint32_t *) 0xe6050000
#define	MOD_SEL 	(volatile uint32_t *) 0xe6050100

extern void PFC_SetBit(volatile uint32_t *reg, uint8_t bitPos);
extern void PFC_ClearBit(volatile uint32_t *reg, uint8_t bitPos);
extern void PFC_WriteAnd(volatile uint32_t *reg, uint32_t data);
extern void PFC_WriteOr(volatile uint32_t *reg, uint32_t data);

#endif
