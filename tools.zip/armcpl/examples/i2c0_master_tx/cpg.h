
#ifndef CPG_H_
#define CPG_H_

/* Standard libraries */
#include	<stdint.h>

/* CPG registers */
#define	CPGWPR      (volatile uint32_t *)   0xe6150000

/* For I2C only */
#define	MSTPCR5     (volatile uint32_t *)   0xe6152d14
#define	MSTPSR5     (volatile uint32_t *)   0xe6152e14
#define	SFTRST5     (volatile uint32_t *)   0xe6152c14
#define	SFTRSTCLR5  (volatile uint32_t *)   0xe6152c94

#define I2C0_MSTPCR         MSTPCR5
#define I2C1_MSTPCR         MSTPCR5
#define I2C2_MSTPCR         MSTPCR5
#define I2C3_MSTPCR         MSTPCR5
#define I2C4_MSTPCR         MSTPCR5
#define I2C5_MSTPCR         MSTPCR5
#define I2C6_MSTPCR         MSTPCR5

#define I2C0_MSTP_BIT_POS   18
#define I2C1_MSTP_BIT_POS   19
#define I2C2_MSTP_BIT_POS   20
#define I2C3_MSTP_BIT_POS   21
#define I2C4_MSTP_BIT_POS   22
#define I2C5_MSTP_BIT_POS   23
#define I2C6_MSTP_BIT_POS   24

#define I2C0_SFTRST         SFTRST5
#define I2C1_SFTRST         SFTRST5
#define I2C2_SFTRST         SFTRST5
#define I2C3_SFTRST         SFTRST5
#define I2C4_SFTRST         SFTRST5
#define I2C5_SFTRST         SFTRST5
#define I2C6_SFTRST         SFTRST5

#define I2C0_SFTRSTCLR      SFTRSTCLR5
#define I2C1_SFTRSTCLR      SFTRSTCLR5
#define I2C2_SFTRSTCLR      SFTRSTCLR5
#define I2C3_SFTRSTCLR      SFTRSTCLR5
#define I2C4_SFTRSTCLR      SFTRSTCLR5
#define I2C5_SFTRSTCLR      SFTRSTCLR5
#define I2C6_SFTRSTCLR      SFTRSTCLR5

#define I2C0_SRST_BIT_POS   18
#define I2C1_SRST_BIT_POS   19
#define I2C2_SRST_BIT_POS   20
#define I2C3_SRST_BIT_POS   21
#define I2C4_SRST_BIT_POS   22
#define I2C5_SRST_BIT_POS   23
#define I2C6_SRST_BIT_POS   24

extern void CPG_SetBit(volatile uint32_t *reg, uint8_t bitPos);
extern void CPG_ClearBit(volatile uint32_t *reg, uint8_t bitPos);
extern void CPG_WriteAnd(volatile uint32_t *reg, uint32_t data);
extern void CPG_WriteOr(volatile uint32_t *reg, uint32_t data);

#endif
