
/* Standard libraries */
#include    <stdint.h>

#include    "pfc.h"

void PFC_SetBit(volatile uint32_t *reg, uint8_t bitPos)
{
	uint32_t data = 1 << bitPos;
	*PMMR = ~data;
	*reg |= data;
}

void PFC_ClearBit(volatile uint32_t *reg, uint8_t bitPos)
{
	uint32_t data = ~(1 << bitPos);
	*PMMR = ~data;
	*reg &= data;
}

void PFC_WriteAnd(volatile uint32_t *reg, uint32_t data)
{
	*PMMR = ~data;
	*reg &= data;
}

void PFC_WriteOr(volatile uint32_t *reg, uint32_t data)
{
	*PMMR = ~data;
	*reg |= data;
}
