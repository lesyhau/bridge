
/******************************************************************************
 *
 * I2C definition and library.
 * 
 * 2082 - Hau Sy Le - hau.le.eb@renesas.com
 *
 ****************************************************************************/

/* Standard C libraries */
#include <stdint.h>

#include "i2c.h"
#include "i2c_v3u.h"

/******************************************************************************
 *
 * Subroutines for slave mode
 *
 *****************************************************************************/

void I2C_slaveInit(I2C_t *i2c, const I2C_SlaveConfig_t * slaveConfig)
{
    /* Set slave address */
    i2c->ICSAR = slaveConfig->SlaveAddress;
    
    uint32_t icscr = 0;

    /* Select single buffer mode */
    icscr |= SDBS_MASK;

    /* Configure slave clock stretch mode */
    switch (slaveConfig->ClockStretchMode)
    {
    case CLOCK_STRETCH_BEFORE:
        icscr &= ~SCSS_MASK;
        break;

    case CLOCK_STRETCH_AFTER:
        icscr |= SCSS_MASK;
        break;

    default:
        icscr &= ~SCSS_MASK;
        break;
    }

    /* Configure general call ACK mode */
    switch (slaveConfig->GenCallMode)
    {
    case GENERAL_CALL_ACK_DISABLE:
        icscr &= ~GCAE_MASK;
        break;

    case GENERAL_CALL_ACK_ENABLE:
        icscr |= GCAE_MASK;
        break;

    default:
        icscr &= ~GCAE_MASK;
        break;
    }

    i2c->ICSCR = icscr;

    /* Configure clock rate and clock type */
    switch (slaveConfig->IOBufferType)
    {
    case OD_BUFFER:
        switch (slaveConfig->ClockType)
        {
        case FIXED_DUTY_CYCLE:
            i2c->ICCCR2 &= ~(CDFD_MASK | HLSE_MASK | SME_MASK);
            switch (slaveConfig->ClockRate)
            {
            case CLOCK_RATE_100KHZ:
                i2c->ICCCR = 0xAE;
                i2c->ICMPR = 0;
                i2c->ICHPR = 0;
                i2c->ICLPR = 0;
                break;

            case CLOCK_RATE_400KHZ:
                i2c->ICCCR = 0x1E;
                i2c->ICMPR = 0;
                i2c->ICHPR = 0;
                i2c->ICLPR = 0;
                break;

            case CLOCK_RATE_1MHZ:
                i2c->ICCCR = 0x1E;
                i2c->ICMPR = 0;
                i2c->ICHPR = 0;
                i2c->ICLPR = 0;
                break;

            default:
                /* Default clock rate is 400kHz */
                i2c->ICCCR = 0x1E;
                i2c->ICMPR = 0;
                i2c->ICHPR = 0;
                i2c->ICLPR = 0;
                break;
            }
            break;

        case VARIABLE_DUTY_CYCLE:
            i2c->ICCCR2 |= (CDFD_MASK | HLSE_MASK | SME_MASK);
            switch (slaveConfig->ClockRate)
            {
            case CLOCK_RATE_100KHZ:
                i2c->ICCCR = 0x06;
                i2c->ICMPR = 20;
                i2c->ICHPR = 632;
                i2c->ICLPR = 653;
                break;

            case CLOCK_RATE_400KHZ:
                i2c->ICCCR = 0x06;
                i2c->ICMPR = 21;
                i2c->ICHPR = 133;
                i2c->ICLPR = 150;
                break;

            case CLOCK_RATE_1MHZ:
                i2c->ICCCR = 0x06;
                i2c->ICMPR = 21;
                i2c->ICHPR = 133;
                i2c->ICLPR = 150;
                break;

            default:
                /* Default clock rate is 400kHz */
                i2c->ICCCR = 0x06;
                i2c->ICMPR = 21;
                i2c->ICHPR = 133;
                i2c->ICLPR = 150;
                break;
            }
            break;

        default:
            /* Default clock rate is 400kHz and with fixed duty cycle */
            i2c->ICCCR2 &= ~(CDFD_MASK | HLSE_MASK | SME_MASK);
            i2c->ICCCR = 0x1E;
            i2c->ICMPR = 0;
            i2c->ICHPR = 0;
            i2c->ICLPR = 0;
            break;
        }
        break;

    case LVTTL_BUFFER:
        switch (slaveConfig->ClockType)
        {
        case FIXED_DUTY_CYCLE:
            i2c->ICCCR2 &= ~(CDFD_MASK | HLSE_MASK | SME_MASK);
            switch (slaveConfig->ClockRate)
            {
            case CLOCK_RATE_100KHZ:
                i2c->ICCCR = 0xAE;
                i2c->ICMPR = 0;
                i2c->ICHPR = 0;
                i2c->ICLPR = 0;
                break;

            case CLOCK_RATE_400KHZ:
                i2c->ICCCR = 0x1E;
                i2c->ICMPR = 0;
                i2c->ICHPR = 0;
                i2c->ICLPR = 0;
                break;

            case CLOCK_RATE_1MHZ:
                i2c->ICCCR = 0x1E;
                i2c->ICMPR = 0;
                i2c->ICHPR = 0;
                i2c->ICLPR = 0;
                break;

            default:
                /* Default clock rate is 400kHz */
                i2c->ICCCR = 0x1E;
                i2c->ICMPR = 0;
                i2c->ICHPR = 0;
                i2c->ICLPR = 0;
                break;
            }
            break;

        case VARIABLE_DUTY_CYCLE:
            i2c->ICCCR2 |= (CDFD_MASK | HLSE_MASK | SME_MASK);
            switch (slaveConfig->ClockRate)
            {
            case CLOCK_RATE_100KHZ:
                i2c->ICCCR = 0x06;
                i2c->ICMPR = 14;
                i2c->ICHPR = 639;
                i2c->ICLPR = 658;
                break;

            case CLOCK_RATE_400KHZ:
                i2c->ICCCR = 0x06;
                i2c->ICMPR = 16;
                i2c->ICHPR = 138;
                i2c->ICLPR = 155;
                break;

            case CLOCK_RATE_1MHZ:
                i2c->ICCCR = 0x06;
                i2c->ICMPR = 16;
                i2c->ICHPR = 138;
                i2c->ICLPR = 155;
                break;

            default:
                /* Default clock rate is 400kHz */
                i2c->ICCCR = 0x06;
                i2c->ICMPR = 16;
                i2c->ICHPR = 138;
                i2c->ICLPR = 155;
                break;
            }
            break;

        default:
            /* Default clock rate is 400kHz and with fixed duty cycle */
            i2c->ICCCR2 &= ~(CDFD_MASK | HLSE_MASK | SME_MASK);
            i2c->ICCCR = 0x1E;
            i2c->ICMPR = 0;
            i2c->ICHPR = 0;
            i2c->ICLPR = 0;
            break;
        }
        break;

    default:
        /* Default clock rate is 400kHz and with fixed duty cycle and use OD buffer */
        i2c->ICCCR2 &= ~(CDFD_MASK | HLSE_MASK | SME_MASK);
        i2c->ICCCR = 0x1E;
        i2c->ICMPR = 0;
        i2c->ICHPR = 0;
        i2c->ICLPR = 0;
        break;
    }
}

void I2C_slaveEnable(I2C_t *i2c)
{
    i2c->ICSCR |= SIE_MASK;
}

void I2C_slaveDisable(I2C_t *i2c)
{
    i2c->ICSCR &= ~SIE_MASK;
}

void I2C_slaveEnableInterrupt(I2C_t *i2c, uint32_t flag)
{
    i2c->ICSIER |= flag;
}

void I2C_slaveDisableInterrupt(I2C_t *i2c, uint32_t flag)
{
    i2c->ICSIER &= ~flag;
}

uint32_t I2C_slaveGetInterruptStatus(I2C_t *i2c)
{
    return (i2c->ICSSR);
}

void I2C_slaveClearInterruptStatus(I2C_t *i2c, uint32_t flag)
{
    i2c->ICSSR &= ~flag;
}

void I2C_slaveForceNAK(I2C_t *i2c)
{
    i2c->ICSCR |= FNA_MASK;
}

uint32_t I2C_slaveReceiveMultipleByteNext(I2C_t *i2c)
{
    /* Get the received byte */
    return (i2c->ICRXD);
}

uint32_t I2C_slaveReceiveMultipleByteStop(I2C_t *i2c)
{
    /* Get the received byte and send NACK on the next received byte */
    i2c->FNA = 1;
    return (i2c->ICRXD);
}

uint32_t I2C_slaveReceiveMultipleByteFinish(I2C_t *i2c)
{
    /* Get the last received byte */
    return (i2c->ICRXD);
}

void I2C_slaveEnableDMAReceive(I2C_t *i2c)
{
    i2c->ICDMAER |= RSDMAE_MASK;
}

void I2C_slaveDisableDMAReceive(I2C_t *i2c)
{
    i2c->ICDMAER &= ~RSDMAE_MASK;
}

void I2C_slaveEnableDMATransmit(I2C_t *i2c)
{
    i2c->ICDMAER |= TSDMAE_MASK;
}

void I2C_slaveDisableDMATransmit(I2C_t *i2c)
{
    i2c->ICDMAER &= ~TSDMAE_MASK;
}

/******************************************************************************
 *
 * Subroutines for master mode
 *
 *****************************************************************************/

void I2C_masterInit(I2C_t *i2c, const I2C_MasterConfig_t *masterConfig)
{
    /* Set slave address and configure transfer mode */
    i2c->ICMAR = (masterConfig->SlaveAddress << 1 | masterConfig->TransferMode);

    uint32_t icmcr = 0;

    /* Select single buffer mode */
    icmcr |= MDBS_MASK;

    /* Configure start byte transmit mode */
    switch (masterConfig->StartByteTransmitMode)
    {
    case START_BYTE_TRANSMIT_DISABLE:
        icmcr &= ~TSBE_MASK;
        break;

    case START_BYTE_TRANSMIT_ENABLE:
        icmcr |= TSBE_MASK;
        break;

    default:
        /* Default is start byte transmit disabled */
        icmcr &= ~TSBE_MASK;
        break;
    }

    i2c->ICMCR = icmcr;

    /* Configure clock rate and clock type */
    switch (masterConfig->IOBufferType)
    {
    case OD_BUFFER:
        switch (masterConfig->ClockType)
        {
        case FIXED_DUTY_CYCLE:
            i2c->ICCCR2 &= ~(CDFD_MASK | HLSE_MASK | SME_MASK);
            switch (masterConfig->ClockRate)
            {
            case CLOCK_RATE_100KHZ:
                i2c->ICCCR = 0xAE;
                i2c->ICMPR = 0;
                i2c->ICHPR = 0;
                i2c->ICLPR = 0;
                break;

            case CLOCK_RATE_400KHZ:
                i2c->ICCCR = 0x1E;
                i2c->ICMPR = 0;
                i2c->ICHPR = 0;
                i2c->ICLPR = 0;
                break;

            case CLOCK_RATE_1MHZ:
                i2c->ICCCR = 0x1E;
                i2c->ICMPR = 0;
                i2c->ICHPR = 0;
                i2c->ICLPR = 0;
                break;

            default:
                /* Default clock rate is 400kHz */
                i2c->ICCCR = 0x1E;
                i2c->ICMPR = 0;
                i2c->ICHPR = 0;
                i2c->ICLPR = 0;
                break;
            }
            break;

        case VARIABLE_DUTY_CYCLE:
            i2c->ICCCR2 |= (CDFD_MASK | HLSE_MASK | SME_MASK);
            switch (masterConfig->ClockRate)
            {
            case CLOCK_RATE_100KHZ:
                i2c->ICCCR = 0x06;
                i2c->ICMPR = 20;
                i2c->ICHPR = 632;
                i2c->ICLPR = 653;
                break;

            case CLOCK_RATE_400KHZ:
                i2c->ICCCR = 0x06;
                i2c->ICMPR = 21;
                i2c->ICHPR = 133;
                i2c->ICLPR = 150;
                break;

            case CLOCK_RATE_1MHZ:
                i2c->ICCCR = 0x06;
                i2c->ICMPR = 21;
                i2c->ICHPR = 133;
                i2c->ICLPR = 150;
                break;

            default:
                /* Default clock rate is 400kHz */
                i2c->ICCCR = 0x06;
                i2c->ICMPR = 21;
                i2c->ICHPR = 133;
                i2c->ICLPR = 150;
                break;
            }
            break;

        default:
            /* Default clock rate is 400kHz and with fixed duty cycle */
            i2c->ICCCR2 &= ~(CDFD_MASK | HLSE_MASK | SME_MASK);
            i2c->ICCCR = 0x1E;
            i2c->ICMPR = 0;
            i2c->ICHPR = 0;
            i2c->ICLPR = 0;
            break;
        }
        break;

    case LVTTL_BUFFER:
        switch (masterConfig->ClockType)
        {
        case FIXED_DUTY_CYCLE:
            i2c->ICCCR2 &= ~(CDFD_MASK | HLSE_MASK | SME_MASK);
            switch (masterConfig->ClockRate)
            {
            case CLOCK_RATE_100KHZ:
                i2c->ICCCR = 0xAE;
                i2c->ICMPR = 0;
                i2c->ICHPR = 0;
                i2c->ICLPR = 0;
                break;

            case CLOCK_RATE_400KHZ:
                i2c->ICCCR = 0x1E;
                i2c->ICMPR = 0;
                i2c->ICHPR = 0;
                i2c->ICLPR = 0;
                break;

            case CLOCK_RATE_1MHZ:
                i2c->ICCCR = 0x1E;
                i2c->ICMPR = 0;
                i2c->ICHPR = 0;
                i2c->ICLPR = 0;
                break;

            default:
                /* Default clock rate is 400kHz */
                i2c->ICCCR = 0x1E;
                i2c->ICMPR = 0;
                i2c->ICHPR = 0;
                i2c->ICLPR = 0;
                break;
            }
            break;

        case VARIABLE_DUTY_CYCLE:
            i2c->ICCCR2 |= (CDFD_MASK | HLSE_MASK | SME_MASK);
            switch (masterConfig->ClockRate)
            {
            case CLOCK_RATE_100KHZ:
                i2c->ICCCR = 0x06;
                i2c->ICMPR = 14;
                i2c->ICHPR = 639;
                i2c->ICLPR = 658;
                break;

            case CLOCK_RATE_400KHZ:
                i2c->ICCCR = 0x06;
                i2c->ICMPR = 16;
                i2c->ICHPR = 138;
                i2c->ICLPR = 155;
                break;

            case CLOCK_RATE_1MHZ:
                i2c->ICCCR = 0x06;
                i2c->ICMPR = 16;
                i2c->ICHPR = 138;
                i2c->ICLPR = 155;
                break;

            default:
                /* Default clock rate is 400kHz */
                i2c->ICCCR = 0x06;
                i2c->ICMPR = 16;
                i2c->ICHPR = 138;
                i2c->ICLPR = 155;
                break;
            }
            break;

        default:
            /* Default clock rate is 400kHz and with fixed duty cycle */
            i2c->ICCCR2 &= ~(CDFD_MASK | HLSE_MASK | SME_MASK);
            i2c->ICCCR = 0x1E;
            i2c->ICMPR = 0;
            i2c->ICHPR = 0;
            i2c->ICLPR = 0;
            break;
        }
        break;

    default:
        /* Default clock rate is 400kHz and with fixed duty cycle and use OD buffer */
        i2c->ICCCR2 &= ~(CDFD_MASK | HLSE_MASK | SME_MASK);
        i2c->ICCCR = 0x1E;
        i2c->ICMPR = 0;
        i2c->ICHPR = 0;
        i2c->ICLPR = 0;
        break;
    }
}

void I2C_masterEnable(I2C_t *i2c)
{
    i2c->ICMCR |= MIE_MASK;
}

void I2C_masterDisable(I2C_t *i2c)
{
    i2c->ICMCR &= ~MIE_MASK;
}

void I2C_masterEnableInterrupt(I2C_t *i2c, uint32_t flag)
{
    i2c->ICMIER |= flag;
}

void I2C_masterDisableInterrupt(I2C_t *i2c, uint32_t flag)
{
    i2c->ICMIER &= ~flag;
}

uint32_t I2C_masterGetInterruptStatus(I2C_t *i2c)
{
    return (i2c->ICMSR);
}

void I2C_masterClearInterruptStatus(I2C_t *i2c, uint32_t flag)
{
    i2c->ICMSR &= ~flag;
}

void I2C_masterForceStop(I2C_t *i2c)
{
    i2c->ICMCR |= FSB_MASK;
}

void I2C_masterSendMultipleByteStart(I2C_t *i2c, uint32_t data)
{
    /* Set the first data byte */
    i2c->ICTXD = data;

    /* Send start condition */
    i2c->ESG = 1;
}

void I2C_masterSendMultipleByteNext(I2C_t *i2c, uint32_t data)
{
    /* Set the next data byte */
    i2c->ICTXD = data;
}

void I2C_masterSendMultipleByteStop(I2C_t *i2c, uint32_t data)
{
    /* Make sure that ESG is cleared */
    i2c->ESG = 0;

    /* Master send stop condition after the next data byte is sent */
    i2c->FSB = 1;

    /* Set the next data byte */
    i2c->ICTXD = data;
}

void I2C_masterSetDMAContinuousTransferCount(I2C_t *i2c, uint8_t transferCount);

void I2C_masterSetDMAContinuousReceiveBlockCount(I2C_t *i2c, uint8_t blockCount);

void I2C_masterSetDMAContinuousTransmitBlockCount(I2C_t *i2c, uint8_t blockCount);

void I2C_masterEnableDMAContinuousReceive(I2C_t *i2c);

void I2C_masterDisableDMAContinuousReceive(I2C_t *i2c);

void I2C_masterEnableDMAContinuousTransmit(I2C_t *i2c);

void I2C_masterDisableDMAContinuousTransmit(I2C_t *i2c);

void I2C_masterEnableDMAReceive(I2C_t *i2c);

void I2C_masterDisableDMAReceive(I2C_t *i2c);

void I2C_masterEnableDMATransmit(I2C_t *i2c);

void I2C_masterDisableDMATransmit(I2C_t *i2c);
