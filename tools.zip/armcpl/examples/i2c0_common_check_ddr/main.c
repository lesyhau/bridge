
#include <stdint.h>
#include <sim_utils.h>
#include <global.h>
#include <v3u.h>
#include <i2c.h>
#include <pfc.h>
#include <cpg.h>
#include <dmac.h>
#include <gic.h>
#include "common_check.h"

#define	TOTAL_PATTERNS	5

const uint32_t (*pattern[])(void) =
{
    &reg_check,
    &mstp_check,
    &srst_check,
    &pad_check,
    &interrupt_check
};

const uint32_t totalPattern = sizeof(pattern) / sizeof(pattern[0]);
uint32_t result[totalPattern];

int main(void)
{
    //Sim_CopyToSRAM();
    //Sim_SetCR52BAR(0xe6300000);

	uint8_t i;
    uint32_t testResult = TEST_PASS;

    for (i = 0; i < totalPattern; i++)
    {
        result[i] = (*pattern[i])();

        /* Only continue if the current pattern result is pass */
        if (result[i] == TEST_FAIL)
        {
            testResult = TEST_FAIL;
            break;
        }
    }

    if (testResult == TEST_FAIL)
    {
	    for (i = 0; i < totalPattern; i++)
	    {
	    	Sim_Dump(result[i]);
	    }
    }

    Sim_Judge(testResult);
    Sim_Dump(0x12345678);
	Sim_Stop();

    while(1);
    return (0);
}

