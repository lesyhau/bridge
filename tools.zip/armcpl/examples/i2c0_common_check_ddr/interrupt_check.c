
#include <stdint.h>
#include <stdbool.h>
#include <sim_utils.h>
#include <global.h>
#include <v3u.h>
#include <i2c.h>
#include <pfc.h>
#include <cpg.h>
#include <gic.h>

static const I2C_MasterConfig_t masterConfig =
{
    MASTER_TX,
    0x5f,
    START_BYTE_TRANSMIT_DISABLE,
    OD_BUFFER,
    FIXED_DUTY_CYCLE,
    CLOCK_RATE_400KHZ
};

static const I2C_SlaveConfig_t slaveConfig =
{
    I2C1_SLAVE_ADDR,
    CLOCK_STRETCH_AFTER,
    GENERAL_CALL_ACK_DISABLE,
    OD_BUFFER,
    FIXED_DUTY_CYCLE,
    CLOCK_RATE_400KHZ
};

volatile uint32_t ackID = 0;
volatile bool isIRQ;
void i2c0InterruptHandler(void);

uint32_t interrupt_check(void)
{
    I2C_configPins();
    I2C_modelConnect(I2C0CH, I2C1CH);

    /* Configure I2C0 in master TX mode */
    I2C_masterInit(I2C0, &masterConfig);
    I2C_masterClearInterruptStatus(I2C0, I2C_INT_ALL);
	I2C_masterEnableInterrupt(I2C0, I2C_INT_MNR);
    I2C_masterEnable(I2C0);

    /* Configure I2C1 in slave RX mode */
    I2C_slaveInit(I2C1, &slaveConfig);
    I2C_slaveClearInterruptStatus(I2C1, I2C_INT_ALL);
    I2C_slaveEnable(I2C1);

	/* Enable interrupt */
    GIC_enable();
    GIC_configInterrupt(GIC_INTID_I2C0, GIC_INT_GROUP_1, 0, GIC_RAISING_EDGE_TRIGGERED);
    GIC_enableInterrupt(GIC_INTID_I2C0);
    GIC_setInterruptHandler(GIC_INTID_I2C0, &i2c0InterruptHandler);
	
    /* Set the first data byte, send start condition, send slave address */
    I2C_masterSendMultipleByteStart(I2C0, 0xaa);

    /* Wait for IRQ subroutine finish */
    while (! isIRQ);

    /**************************************************************************
     * The end of the simulation
     *************************************************************************/

	I2C_modelDisable();
    I2C_releasePins();
	
	/* Judge the result */
	uint32_t testResult = TEST_PASS;
	if (ackID != GIC_INTID_I2C0)
	{
		testResult = TEST_FAIL;
	}

    if (testResult == TEST_FAIL)
    {
        Sim_Dump(ackID);
    }
	
	return testResult;
}

void i2c0InterruptHandler(void)
{
	uint32_t intStatus = I2C_masterGetInterruptStatus(I2C0);
	I2C_masterClearInterruptStatus(I2C0, intStatus);

    ackID = GIC_INTID_I2C0;
    isIRQ = true;
}
