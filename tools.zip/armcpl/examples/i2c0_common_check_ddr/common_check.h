
/******************************************************************************
 *  File name:  common_check.h
 *  Author:     haule2
 *  Date:       Sat Oct 20 11:31:18 ICT 2018
 *****************************************************************************/

#ifndef COMMON_CHECK_H_
#define COMMON_CHECK_H_

#include <stdint.h>

extern uint32_t reg_check(void);
extern uint32_t mstp_check(void);
extern uint32_t srst_check(void);
extern uint32_t pad_check(void);
extern uint32_t interrupt_check(void);

#endif  /* COMMON_CHECK_H_ */

