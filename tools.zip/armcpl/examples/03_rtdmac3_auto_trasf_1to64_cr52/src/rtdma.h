//RTDMAC0
#define DMA0_BASE_ADR_CHANNEL		0xFFC10000		// RT-DMAC0
#define	DMA0_BASE_ADR_PUBLIC		0xFFD60000
//RTDMAC1
#define DMA1_BASE_ADR_CHANNEL		0xFFC20000		// RT-DMAC1
#define DMA1_BASE_ADR_PUBLIC		0xFFD61000
//RTDMAC2
#define DMA2_BASE_ADR_CHANNEL		0xFFD70000		// RT-DMAC2
#define DMA2_BASE_ADR_PUBLIC		0xFFD62000
//RTDMAC3
#define	DMA3_BASE_ADR_CHANNEL		0xFFD80000		// RT-DMAC3
#define	DMA3_BASE_ADR_PUBLIC		0xFFD63000		

//#define DSH0_BASE_ADR	0xE6700000		// RT-DMAC
#define DMA0_CH_NUM		16				// RT-DMAC0
#define DMA1_CH_NUM		16				// RT-DMAC1
#define DMA2_CH_NUM		16				// RT-DMAC2 
#define	DMA3_CH_NUM		16				// RT-DMAC3
//#define DMA_IRQ_BASE	RTDMAC_DEI0	// RT-DMAC

#define DMA_CHCR_DE		0x00000001
#define DMA_CHCR_TE		0x00000002
#define DMA_CHCR_IE		0x00000004
#define DMA_CHCR_BYTE	0x00000000
#define DMA_CHCR_WORD	0x00000008
#define DMA_CHCR_LONG	0x00000010
#define DMA_CHCR_8B		0x00100018
#define DMA_CHCR_16B	0x00000018
#define DMA_CHCR_32B	0x00100000
#define DMA_CHCR_64B	0x00100008
#define DMA_CHCR_BD		0x00000080
#define DMA_CHCR_MMIE	0x00010000
#define DMA_CHCR_MME	0x00020000
#define DMA_CHCR_DSIE	0x00040000
#define DMA_CHCR_DSE	0x00080000
#define DMA_CHCR_DPB	0x00400000
#define DMA_CHCR_MMU	0x00800000
#define DMA_CHCR_CAIE	0x40000000
#define DMA_CHCR_CAE	0x80000000

unsigned long dma_ch_base ( unsigned long ch );

typedef struct __param_dma
{
	unsigned int	ch; // sizeof(ch) = sizeof(int) = 4 bytes = 32 bits
	unsigned int	sar;
	unsigned int	dar;
	unsigned int	tcr;
	unsigned int	chcr;
} Param_DMA; // --> sizeof(Param_DMA) = 4 bytes x 5 (ch, sar, dar, tcr, chcr) = 20 bytes

