#include "rtdma.h"

/* prototype declaration */
void set_dma_param ( Param_DMA *p );
void set_dmaor ( unsigned short dmaor );
void wait_transfer_end ( unsigned long ch );
void func_dma_auto_atst ( int step );
void loop_cycle ( unsigned long cycle );

//__align(16)
unsigned long initial_data[] =
{	// 4 bytes/1 element --> 0x00010000 4 bytes 
	0x00010000,0x00030002,0x00050004,0x00070006,0x00090008,0x000B000A,0x000D000C,0x000F000E,
	0x00110010,0x00130012,0x00150014,0x00170016,0x00190018,0x001B001A,0x001D001C,0x001F001E,
	0x00210020,0x00230022,0x00250024,0x00270026,0x00290028,0x002B002A,0x002D002C,0x002F002E,
	0x00310030,0x00330032,0x00350034,0x00370036,0x00390038,0x003B003A,0x003D003C,0x003F003E,
	0x00410040,0x00430042,0x00450044,0x00470046,0x00490048,0x004B004A,0x004D004C,0x004F004E,
	0x00510050,0x00530052,0x00550054,0x00570056,0x00590058,0x005B005A,0x005D005C,0x005F005E,
	0x00610060,0x00630062,0x00650064,0x00670066,0x00690068,0x006B006A,0x006D006C,0x006F006E,
	0x00710070,0x00730072,0x00750074,0x00770076,0x00790078,0x007B007A,0x007D007C,0x007F007E,
	0x00810080,0x00830082,0x00850084,0x00870086,0x00890088,0x008B008A,0x008D008C,0x008F008E,
	0x00910090,0x00930092,0x00950094,0x00970096,0x00990098,0x009B009A,0x009D009C,0x009F009E,
	0x00A100A0,0x00A300A2,0x00A500A4,0x00A700A6,0x00A900A8,0x00AB00AA,0x00AD00AC,0x00AF00AE,
	0x00B100B0,0x00B300B2,0x00B500B4,0x00B700B6,0x00B900B8,0x00BB00BA,0x00BD00BC,0x00BF00BE,
	0x00C100C0,0x00C300C2,0x00C500C4,0x00C700C6,0x00C900C8,0x00CB00CA,0x00CD00CC,0x00CF00CE,
	0x00D100D0,0x00D300D2,0x00D500D4,0x00D700D6,0x00D900D8,0x00DB00DA,0x00DD00DC,0x00DF00DE,
	0x00E100E0,0x00E300E2,0x00E500E4,0x00E700E6,0x00E900E8,0x00EB00EA,0x00ED00EC,0x00EF00EE,
	0x00F100F0,0x00F300F2,0x00F500F4,0x00F700F6,0x00F900F8,0x00FB00FA,0x00FD00FC,0x00FF00FE,
};

//extern unsigned long public_code;
Param_DMA dma_list[] =
{   // Sar         Dar         Tcr         Chcr
	// BSC->BSC
	{  0, 0x00100000, 0x02100100, 0x00000100, 0x00005401|DMA_CHCR_IE|DMA_CHCR_BYTE },
	{  1, 0x00100000, 0x02100200, 0x00000080, 0x00005401|DMA_CHCR_IE|DMA_CHCR_WORD },
	{  2, 0x00100000, 0x02100300, 0x00000040, 0x00005401|DMA_CHCR_IE|DMA_CHCR_LONG },
	{  3, 0x00100000, 0x02100400, 0x00000020, 0x00005401|DMA_CHCR_IE|DMA_CHCR_8B   },
	{  4, 0x00100000, 0x02100500, 0x00000010, 0x00005401|DMA_CHCR_IE|DMA_CHCR_16B  },
	{  5, 0x00100000, 0x02100600, 0x00000008, 0x00005401|DMA_CHCR_IE|DMA_CHCR_32B  },
	{  6, 0x00100000, 0x02100700, 0x00000004, 0x00005401|DMA_CHCR_IE|DMA_CHCR_64B  },
	{  7, 0x00100000, 0x02100800, 0x00000004, 0x00005401|DMA_CHCR_IE|DMA_CHCR_64B  },
	//DBSC --> DBSC
	{  8, 0x40100000, 0x40100100, 0x00000100, 0x00005401|DMA_CHCR_IE|DMA_CHCR_BYTE },
	{  9, 0x40100000, 0x40100200, 0x00000080, 0x00005401|DMA_CHCR_IE|DMA_CHCR_WORD },
	{ 10, 0x40100000, 0x40100300, 0x00000040, 0x00005401|DMA_CHCR_IE|DMA_CHCR_LONG },
	{ 11, 0x40100000, 0x40100400, 0x00000020, 0x00005401|DMA_CHCR_IE|DMA_CHCR_8B   },
	{ 12, 0x40100000, 0x40100500, 0x00000010, 0x00005401|DMA_CHCR_IE|DMA_CHCR_16B  },
	{ 13, 0x40100000, 0x40100600, 0x00000008, 0x00005401|DMA_CHCR_IE|DMA_CHCR_32B  },
	{ 14, 0x40100000, 0x40100700, 0x00000004, 0x00005401|DMA_CHCR_IE|DMA_CHCR_64B  },
	{ 15, 0x40100000, 0x40100800, 0x00000004, 0x00005401|DMA_CHCR_IE|DMA_CHCR_64B  },
	// LBSC -> DBSC
	{  0, 0x02100100, 0x40100900, 0x00000100, 0x00005401|DMA_CHCR_IE|DMA_CHCR_BYTE },
	{  1, 0x02100200, 0x40100a00, 0x00000080, 0x00005401|DMA_CHCR_IE|DMA_CHCR_WORD },
	{  2, 0x02100300, 0x40100b00, 0x00000040, 0x00005401|DMA_CHCR_IE|DMA_CHCR_LONG },
	{  3, 0x02100400, 0x40100c00, 0x00000020, 0x00005401|DMA_CHCR_IE|DMA_CHCR_8B   },
	{  4, 0x02100500, 0x40100d00, 0x00000010, 0x00005401|DMA_CHCR_IE|DMA_CHCR_16B  },
	{  5, 0x02100600, 0x40100e00, 0x00000008, 0x00005401|DMA_CHCR_IE|DMA_CHCR_32B  },
	{  6, 0x02100700, 0x40100f00, 0x00000004, 0x00005401|DMA_CHCR_IE|DMA_CHCR_64B  },
	{  7, 0x02100800, 0x40101000, 0x00000004, 0x00005401|DMA_CHCR_IE|DMA_CHCR_64B  },
	// DBSC --> LBSC
	{  8, 0x40100100, 0x02100900, 0x00000100, 0x00005401|DMA_CHCR_IE|DMA_CHCR_BYTE },
	{  9, 0x40100200, 0x02100a00, 0x00000080, 0x00005401|DMA_CHCR_IE|DMA_CHCR_WORD },
	{ 10, 0x40100300, 0x02100b00, 0x00000040, 0x00005401|DMA_CHCR_IE|DMA_CHCR_LONG },
	{ 11, 0x40100400, 0x02100c00, 0x00000020, 0x00005401|DMA_CHCR_IE|DMA_CHCR_8B   },
	{ 12, 0x40100500, 0x02100d00, 0x00000010, 0x00005401|DMA_CHCR_IE|DMA_CHCR_16B  },
	{ 13, 0x40100600, 0x02100e00, 0x00000008, 0x00005401|DMA_CHCR_IE|DMA_CHCR_32B  },
	{ 14, 0x40100700, 0x02100f00, 0x00000004, 0x00005401|DMA_CHCR_IE|DMA_CHCR_64B  },
	{ 15, 0x40100800, 0x02101000, 0x00000004, 0x00005401|DMA_CHCR_IE|DMA_CHCR_64B  } 
};

/* main routine */
int main( void )
{
	Param_DMA dma_param;
	int step;

	/* initialize */
	dma_param.ch   = 0;
	dma_param.sar  = (unsigned long)initial_data;
	dma_param.dar  = 0x00100000; 
	dma_param.tcr  = 0x100/sizeof(initial_data[0]);
	dma_param.chcr = 0x00005401|DMA_CHCR_LONG;
	set_dma_param ( &dma_param );
	set_dmaor ( 0x0001 );
	wait_transfer_end ( dma_param.ch );
	set_dmaor ( 0x0000 );

	dma_param.ch   = 1;
	dma_param.sar  = (unsigned long)initial_data;
	dma_param.dar  = 0x40100000;
	dma_param.tcr  = 0x100/sizeof(initial_data[1]);
	dma_param.chcr = 0x00005401|DMA_CHCR_LONG;
	set_dma_param ( &dma_param ); // 
	set_dmaor ( 0x0001 );
	wait_transfer_end ( dma_param.ch );
	set_dmaor ( 0x0000 );

	/* Start DMA */
	func_dma_auto_atst(0);
	loop_cycle(1);
	func_dma_auto_atst(16);

	*( volatile unsigned long * )0x000003F0 = 0x0;
}

//=======================================
// Common
//=======================================
// DMAC base address
unsigned long dma_ch_base ( unsigned long ch ) {
	unsigned long	base_adr;
	base_adr = DMA3_BASE_ADR_CHANNEL | 0x00000000 | (ch << 12);
	return base_adr;
}

// Set DMA Parameter
void set_dma_param ( Param_DMA *p ) {
	*( volatile unsigned long * )( dma_ch_base(p->ch)|0x00 ) = p->sar; // see tm of interrupt
	*( volatile unsigned long * )( dma_ch_base(p->ch)|0x04 ) = p->dar;
	*( volatile unsigned long * )( dma_ch_base(p->ch)|0x08 ) = p->tcr;
	*( volatile unsigned long * )( dma_ch_base(p->ch)|0x0c ) = p->chcr;
}

// Set DMAOR
void set_dmaor ( unsigned short dmaor ) {
	*( volatile unsigned short * )( DMA3_BASE_ADR_PUBLIC | 0x60 ) = dmaor;
}

// Wait Transfer End
void wait_transfer_end ( unsigned long ch ) {
	unsigned long chcr;
	do {
		chcr = *( volatile unsigned long * )( dma_ch_base(ch)|0xc );
	} while ( ~chcr & DMA_CHCR_TE ); //DMA_CHCR_TE		0x00000002
	*( volatile unsigned long * )( dma_ch_base(ch)|0xc ) &= ~(DMA_CHCR_DSE|DMA_CHCR_TE|DMA_CHCR_DE);
}


void loop_cycle ( unsigned long cycle ) {
        int k;
        k = 0;
        do
        {
                k++;
        } while(k!= cycle);
}

//=======================================
// Main Function
//=======================================
void func_dma_auto_atst ( int step ) {

	int i,ch;
	unsigned long chcr_reg;

	for ( i=step; i<(16+step); i++) { 
		set_dma_param ( &dma_list[i] );
	}

		set_dmaor(0x0001);

	for ( i=step; i<(16+step); i++) {
		do {
			chcr_reg = *( volatile unsigned long * )( dma_ch_base(dma_list[i].ch)|0x0c );
		} while ( ~chcr_reg & DMA_CHCR_TE  );

		*( volatile unsigned long * )( dma_ch_base(dma_list[i].ch)|0x0c ) &= ~(DMA_CHCR_DSE|DMA_CHCR_TE|DMA_CHCR_DE);// the order of operator??
	}
		set_dmaor(0x0000); // off DMAC

}

