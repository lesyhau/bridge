/*
 * What is the fastest way to copy memory on a Cortex-A8?
 *   http://infocenter.arm.com/help/topic/com.arm.doc.faqs/ka13544.html
 */

#include <stdio.h>

//##############
//DSB command
//__attribute__((naked)) void issue_DSB(void *str1 , const void *str2 , size_t len);
__attribute__((naked)) void issue_DSB();
__attribute__((naked)) void issue_DSB()
{
  __asm("DSB");
}
__attribute__((naked)) void issue_WFI();
__attribute__((naked)) void issue_WFI()
{
    __asm("WFI");
}

//############
//
////*******************************************
// 1.Word by Word memory copy
//*******************************************
//__asm void WordCopy (void *str1 , const void *str2, size_t len ) {
//      LDR r3, [r1], #4
//      STR r3, [r0], #4
//      SUBS r2, r2, #4
//      BGE WordCopy
//      BX  lr
//}

//
//###################
//attribute naked reference usage (cannot input parameter from C program to this function)
//__attribute__((naked)) void WordCopy(void *str1 , const void *str2 , size_t len);
//__attribute__((naked)) void WordCopy(void *str1 , const void *str2 , size_t len)
//{
//  __asm("LDR r3, [r1], #4");
////  __asm("LDR r3, %[input_str2], #4"
////      :
////      : [input_str2] "r" (str2)
////      );
////  __asm("STR r3, [r0], #4");
//  __asm("STR r3, [r0], #4");
////  __asm("SUBS r2, r2, #4");
//  __asm("SUBS r2, r2, #4");
//  __asm("BGE WordCopy");
//  __asm("BX lr");
//}
//############ end attribute naked refer
//void WordCopy (void *str1 , const void *str2 , size_t len)
//{
//   __asm (
////       "LDR r3, %[input_str2], #4"
//       "LDR r3, [%[input_str2]], #4"
//       :
//       : [input_str2] "r" (str2)
//       );
//   __asm (
//       "STR r3, [%[input_str1]], #4"
//       :
//       : [input_str1] "r" (str1)
//       );
//   __asm (
//       "SUBS %[input_len], %[input_len], #4"
//       :
//       : [input_len] "r" (len)
//       );
//   __asm (
//       "BGE WordCopy"
//       :
//       :
//       );
//   __asm (
//       "BX lr"
//       :
//       :
//       );
// }
//
////*******************************************
// 2.Load-Multiple memory copy
//*******************************************
//__asm void LDMCopy (void *str1 , const void *str2, size_t len ) {
//      PUSH {r4-r10, lr}
//LDMloop
//      LDMIA r1!, {r3 - r10}
//      STMIA r0!, {r3 - r10}
//      SUBS r2, r2, #32
//      BGE LDMloop
//      POP {r4-r10, pc}
//}
//
//void LDMCopy  (void *str1 , const void *str2 , size_t len)
//{
//   __asm (
////       "LDR r3, %[input_str2], #4"
//       "LDR r3, [%[input_str2]], #4"
//       :
//       : [input_str2] "r" (str2)
//       );
//   __asm (
//       "STR r3, [%[input_str1]], #4"
//       :
//       : [input_str1] "r" (str1)
//       );
//   __asm (
//       "SUBS %[input_len], %[input_len], #4"
//       :
//       : [input_len] "r" (len)
//       );
//   __asm (
//       "BGE WordCopy"
//       :
//       :
//       );
//   __asm (
//       "BX lr"
//       :
//       :
//       );
// }

//*******************************************
//// 4.Word by Word memory copy with preload
////*******************************************
//__asm void WordCopyPLD (void *str1 , const void *str2, size_t len ) {
//      PLD [r1, #0x100]
//      MOV r12, #16
//WordCopyPLD1
//      LDR r3, [r1], #4
//      STR r3, [r0], #4
//      SUBS r12, r12, #1
//      BNE WordCopyPLD1
//      SUBS r2, r2, #0x40
//      BNE WordCopyPLD
//      BX  lr
//}
//
//
////*******************************************
//// 5. Load-Multiple memory copy with preload
////*******************************************
//__asm void LDMCopyPLD (void *str1 , const void *str2, size_t len ) {
//      PUSH {r4-r10, lr}
//LDMloopPLD
//      PLD [r1, #0x80]
//      LDMIA r1!, {r3 - r10}
//      STMIA r0!, {r3 - r10}
//      LDMIA r1!, {r3 - r10}
//      STMIA r0!, {r3 - r10}
//      SUBS r2, r2, #0x40
//      BGE LDMloopPLD
//      POP {r4-r10, pc}
//}
//
////*******************************************
//// 5+. Load-Multiple memory copy with preload (tune for cr7, rcarh3)
////*******************************************
//__asm void LDMCopyPLD_TUNE (void *str1 , const void *str2, size_t len ){
//      PUSH {r4-r10, lr}
//      PLD [r1, #0x00]
//      PLD [r1, #0x20]
//LDMloopPLD_TUNE
//      PLD [r1, #0x40]
//      PLD [r1, #0x60]
//      LDMIA r1!, {r3 - r10}
//      STMIA r0!, {r3 - r10}
//      LDMIA r1!, {r3 - r10}
//      STMIA r0!, {r3 - r10}
//      SUBS r2, r2, #0x40
//      BGE LDMloopPLD_TUNE
//      POP {r4-r10, pc}
//}
