//-----------------------------------------------------------------------------
// The confidential and proprietary information contained in this file may
// only be used by a person authorised under and to the extent permitted
// by a subsisting licensing agreement from ARM Limited or its affiliates.
//
//            (C) COPYRIGHT 2014-2017 ARM Limited or its affiliates.
//                ALL RIGHTS RESERVED
//
// This entire notice must be reproduced on all copies of this file
// and copies of this file may only be made by a person if such person is
// permitted to do so under the terms of a subsisting license agreement
// from ARM Limited or its affiliates.
//
//      SVN Information
//
//      Checked In          : $Date: 2016-07-05 16:40:55 +0100 (Tue, 05 Jul 2016) $
//
//      Revision            : $Revision: 347617 $
//
//      Release Information : Cortex-R52 Processor MP040-r1p1-00rel0
//
//------------------------------------------------------------------------------

#define TUBE_ADDRESS ((volatile char *) 0xb0000000)

// This function writes a character to the tube
void output_char(char c)
{
    *TUBE_ADDRESS = c;
}

// This function writes a string to the tube
void print_string(char* string)
{
  char* c   = string;

  while (*c)
  {
    *TUBE_ADDRESS = *c;
    c++;
  }
}

// This function writes an integer to the tube
// First it converts it into a string of ASCII
void print_int(unsigned int integer)
{
  char number_string_inverse[100];
  char number_string[100];
  int  count, cont_inverse;

  count = 0;
  // Force to print always at least one character
  while ((integer > 0) || (count == 0))
  {
    number_string_inverse[count] = integer % 10 + 48; // Add the offset for 0 to the remainder
    integer   = integer / 10;
    count++;
  }

  number_string[count] = 0;
  cont_inverse = 0;
  while (count>0)
  {
    count--;
    number_string[count] = number_string_inverse[cont_inverse];
    cont_inverse++;
  }

  print_string(number_string);
}

// This function prints ** TEST PASSED OK ** and terminates the test by writing on the tube
void benchmark_completed_success()
{
  print_string("** TEST PASSED OK **\n");

//*TUBE_ADDRESS = 0x4;
  // Print 0x4 (EOT character) to end the test
  asm("dsb");
  asm("isb");
  *TUBE_ADDRESS = 0x4;
  asm("dsb");
  asm("wfi");
  // Assembly branch to itself for ending test
  asm("to_here: b to_here");
}

// This function prints ** TEST FAILED ** and terminates the test by writing on the tube
void benchmark_failure()
{
  print_string("** TEST FAILED **\n");

  *TUBE_ADDRESS = 0x4;
}
