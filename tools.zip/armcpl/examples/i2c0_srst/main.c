
/* Standard library */
#include <stdint.h>

/* R-Car Gen 3 I2C library */
#include "i2c.h"
#include "i2c_v3u.h"
#include "cpg.h"

/* Simulation utilities */
#include "sim_utils.h"

void checkRWReg(void);
void checkRegInit(void);

int main(void)
{
    /* Check registers initial value */
    checkRegInit();

    /* While software reset off*/
    checkRWReg();

    /* Activate software reset signal */
    CPG_SetBit(I2C0_SFTRST, I2C0_SRST_BIT_POS); 

    /* While software reset on */
    checkRWReg();

    /* Deactivate software reset signal */
    CPG_SetBit(I2C0_SFTRSTCLR, I2C0_SRST_BIT_POS); 

    /* Check registers initial value */
    checkRegInit();

    Sim_Dump(0x12345678);
	Sim_Stop();

    while(1);

    return (0);
}

void checkRegInit(void)
{
    *DumpPtr = I2C0->ICSCR;
    DumpPtr += 1;

    //

    *DumpPtr = I2C0->ICMCR;
    DumpPtr += 1;

    //

    *DumpPtr = I2C0->ICSSR;
    DumpPtr += 1;

    //

    *DumpPtr = I2C0->ICMSR;
    DumpPtr += 1;

    //

    *DumpPtr = I2C0->ICSIER;
    DumpPtr += 1;

    //

    *DumpPtr = I2C0->ICMIER;
    DumpPtr += 1;

    //

    *DumpPtr = I2C0->ICCCR;
    DumpPtr += 1;

    //

    *DumpPtr = I2C0->ICSAR;
    DumpPtr += 1;

    //

    *DumpPtr = I2C0->ICMAR;
    DumpPtr += 1;

    //

    *DumpPtr = I2C0->ICRXD;
    DumpPtr += 1;

    //

    *DumpPtr = I2C0->ICCCR2;
    DumpPtr += 1;

    //

    *DumpPtr = I2C0->ICMPR;
    DumpPtr += 1;

    //

    *DumpPtr = I2C0->ICHPR;
    DumpPtr += 1;

    //

    *DumpPtr = I2C0->ICLPR;
    DumpPtr += 1;

    //

    *DumpPtr = I2C0->ICFBSCR;
    DumpPtr += 1;

    //

    *DumpPtr = I2C0->ICDMAER;
    DumpPtr += 1;
}

void checkRWReg(void)
{
    I2C0->ICSCR = 0xffffffff;
    *DumpPtr = I2C0->ICSCR;
    DumpPtr += 1;

    I2C0->ICSCR = 0xa5a5a5a5;
    *DumpPtr = I2C0->ICSCR;
    DumpPtr += 1;

    I2C0->ICSCR = 0x5a5a5a5a;
    *DumpPtr = I2C0->ICSCR;
    DumpPtr += 1;

    I2C0->ICSCR = 0x00000000;
    *DumpPtr = I2C0->ICSCR;
    DumpPtr += 1;

    //

    I2C0->ICMCR = 0xffffffff;
    *DumpPtr = I2C0->ICMCR;
    DumpPtr += 1;

    I2C0->ICMCR = 0xa5a5a5a5;
    *DumpPtr = I2C0->ICMCR;
    DumpPtr += 1;

    I2C0->ICMCR = 0x5a5a5a5a;
    *DumpPtr = I2C0->ICMCR;
    DumpPtr += 1;

    I2C0->ICMCR = 0x00000000;
    *DumpPtr = I2C0->ICMCR;
    DumpPtr += 1;

    //

    I2C0->ICSSR = 0xffffffff;
    *DumpPtr = I2C0->ICSSR;
    DumpPtr += 1;

    I2C0->ICSSR = 0xa5a5a5a5;
    *DumpPtr = I2C0->ICSSR;
    DumpPtr += 1;

    I2C0->ICSSR = 0x5a5a5a5a;
    *DumpPtr = I2C0->ICSSR;
    DumpPtr += 1;

    I2C0->ICSSR = 0x00000000;
    *DumpPtr = I2C0->ICSSR;
    DumpPtr += 1;

    //

    I2C0->ICMSR = 0xffffffff;
    *DumpPtr = I2C0->ICMSR;
    DumpPtr += 1;

    I2C0->ICMSR = 0xa5a5a5a5;
    *DumpPtr = I2C0->ICMSR;
    DumpPtr += 1;

    I2C0->ICMSR = 0x5a5a5a5a;
    *DumpPtr = I2C0->ICMSR;
    DumpPtr += 1;

    I2C0->ICMSR = 0x00000000;
    *DumpPtr = I2C0->ICMSR;
    DumpPtr += 1;

    //

    I2C0->ICSIER = 0xffffffff;
    *DumpPtr = I2C0->ICSIER;
    DumpPtr += 1;

    I2C0->ICSIER = 0xa5a5a5a5;
    *DumpPtr = I2C0->ICSIER;
    DumpPtr += 1;

    I2C0->ICSIER = 0x5a5a5a5a;
    *DumpPtr = I2C0->ICSIER;
    DumpPtr += 1;

    I2C0->ICSIER = 0x00000000;
    *DumpPtr = I2C0->ICSIER;
    DumpPtr += 1;

    //

    I2C0->ICMIER = 0xffffffff;
    *DumpPtr = I2C0->ICMIER;
    DumpPtr += 1;

    I2C0->ICMIER = 0xa5a5a5a5;
    *DumpPtr = I2C0->ICMIER;
    DumpPtr += 1;

    I2C0->ICMIER = 0x5a5a5a5a;
    *DumpPtr = I2C0->ICMIER;
    DumpPtr += 1;

    I2C0->ICMIER = 0x00000000;
    *DumpPtr = I2C0->ICMIER;
    DumpPtr += 1;

    //

    I2C0->ICCCR = 0xffffffff;
    *DumpPtr = I2C0->ICCCR;
    DumpPtr += 1;

    I2C0->ICCCR = 0xa5a5a5a5;
    *DumpPtr = I2C0->ICCCR;
    DumpPtr += 1;

    I2C0->ICCCR = 0x5a5a5a5a;
    *DumpPtr = I2C0->ICCCR;
    DumpPtr += 1;

    I2C0->ICCCR = 0x00000000;
    *DumpPtr = I2C0->ICCCR;
    DumpPtr += 1;

    //

    I2C0->ICSAR = 0xffffffff;
    *DumpPtr = I2C0->ICSAR;
    DumpPtr += 1;

    I2C0->ICSAR = 0xa5a5a5a5;
    *DumpPtr = I2C0->ICSAR;
    DumpPtr += 1;

    I2C0->ICSAR = 0x5a5a5a5a;
    *DumpPtr = I2C0->ICSAR;
    DumpPtr += 1;

    I2C0->ICSAR = 0x00000000;
    *DumpPtr = I2C0->ICSAR;
    DumpPtr += 1;

    //

    I2C0->ICMAR = 0xffffffff;
    *DumpPtr = I2C0->ICMAR;
    DumpPtr += 1;

    I2C0->ICMAR = 0xa5a5a5a5;
    *DumpPtr = I2C0->ICMAR;
    DumpPtr += 1;

    I2C0->ICMAR = 0x5a5a5a5a;
    *DumpPtr = I2C0->ICMAR;
    DumpPtr += 1;

    I2C0->ICMAR = 0x00000000;
    *DumpPtr = I2C0->ICMAR;
    DumpPtr += 1;

    //

    I2C0->ICTXD = 0xffffffff;
    *DumpPtr = I2C0->ICRXD;
    DumpPtr += 1;

    I2C0->ICTXD = 0xa5a5a5a5;
    *DumpPtr = I2C0->ICRXD;
    DumpPtr += 1;

    I2C0->ICTXD = 0x5a5a5a5a;
    *DumpPtr = I2C0->ICRXD;
    DumpPtr += 1;

    I2C0->ICTXD = 0x00000000;
    *DumpPtr = I2C0->ICRXD;
    DumpPtr += 1;

    //

    I2C0->ICCCR2 = 0xffffffff;
    *DumpPtr = I2C0->ICCCR2;
    DumpPtr += 1;

    I2C0->ICCCR2 = 0xa5a5a5a5;
    *DumpPtr = I2C0->ICCCR2;
    DumpPtr += 1;

    I2C0->ICCCR2 = 0x5a5a5a5a;
    *DumpPtr = I2C0->ICCCR2;
    DumpPtr += 1;

    I2C0->ICCCR2 = 0x00000000;
    *DumpPtr = I2C0->ICCCR2;
    DumpPtr += 1;

    //

    I2C0->ICMPR = 0xffffffff;
    *DumpPtr = I2C0->ICMPR;
    DumpPtr += 1;

    I2C0->ICMPR = 0xa5a5a5a5;
    *DumpPtr = I2C0->ICMPR;
    DumpPtr += 1;

    I2C0->ICMPR = 0x5a5a5a5a;
    *DumpPtr = I2C0->ICMPR;
    DumpPtr += 1;

    I2C0->ICMPR = 0x00000000;
    *DumpPtr = I2C0->ICMPR;
    DumpPtr += 1;

    //

    I2C0->ICHPR = 0xffffffff;
    *DumpPtr = I2C0->ICHPR;
    DumpPtr += 1;

    I2C0->ICHPR = 0xa5a5a5a5;
    *DumpPtr = I2C0->ICHPR;
    DumpPtr += 1;

    I2C0->ICHPR = 0x5a5a5a5a;
    *DumpPtr = I2C0->ICHPR;
    DumpPtr += 1;

    I2C0->ICHPR = 0x00000000;
    *DumpPtr = I2C0->ICHPR;
    DumpPtr += 1;

    //

    I2C0->ICLPR = 0xffffffff;
    *DumpPtr = I2C0->ICLPR;
    DumpPtr += 1;

    I2C0->ICLPR = 0xa5a5a5a5;
    *DumpPtr = I2C0->ICLPR;
    DumpPtr += 1;

    I2C0->ICLPR = 0x5a5a5a5a;
    *DumpPtr = I2C0->ICLPR;
    DumpPtr += 1;

    I2C0->ICLPR = 0x00000000;
    *DumpPtr = I2C0->ICLPR;
    DumpPtr += 1;

    //

    I2C0->ICFBSCR = 0xffffffff;
    *DumpPtr = I2C0->ICFBSCR;
    DumpPtr += 1;

    I2C0->ICFBSCR = 0xa5a5a5a5;
    *DumpPtr = I2C0->ICFBSCR;
    DumpPtr += 1;

    I2C0->ICFBSCR = 0x5a5a5a5a;
    *DumpPtr = I2C0->ICFBSCR;
    DumpPtr += 1;

    I2C0->ICFBSCR = 0x00000000;
    *DumpPtr = I2C0->ICFBSCR;
    DumpPtr += 1;

    //

    I2C0->ICDMAER = 0xffffffff;
    *DumpPtr = I2C0->ICDMAER;
    DumpPtr += 1;

    I2C0->ICDMAER = 0xa5a5a5a5;
    *DumpPtr = I2C0->ICDMAER;
    DumpPtr += 1;

    I2C0->ICDMAER = 0x5a5a5a5a;
    *DumpPtr = I2C0->ICDMAER;
    DumpPtr += 1;

    I2C0->ICDMAER = 0x00000000;
    *DumpPtr = I2C0->ICDMAER;
    DumpPtr += 1;
}

/******************************************************************************
 *
 * Exception handlers
 *
 ****************************************************************************/

void Default_Handler                 (void) __attribute__((weak));;
void UndefinedInstruction_Handler    (void) __attribute__((weak, alias("Default_Handler")));
void SupervisorCall_Handler          (void) __attribute__((weak, alias("Default_Handler")));
void PrefetchAbort_Handler           (void) __attribute__((weak, alias("Default_Handler")));
void DataAbort_Handler               (void) __attribute__((weak, alias("Default_Handler")));
void IRQ_Handler                     (void) __attribute__((weak, alias("Default_Handler")));
void FIQ_Handler                     (void) __attribute__((weak, alias("Default_Handler")));

void Default_Handler(void)
{
    /* Infinity loop */
    while(1);
}

