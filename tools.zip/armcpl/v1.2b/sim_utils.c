
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sim_utils.h>

volatile uint32_t * DumpPtr = (volatile uint32_t *)MEM_DUMP_AREA_ADDR;

/* Write 4-bytes data out to BSC */
void Sim_Dump(uint32_t data)
{
    *DumpPtr = data;
    DumpPtr += 1;
}

/* Write 4-bytes data out to BSC and wait until the data is written */
void Sim_DumpCheck(uint32_t data)
{
    Sim_Dump(data);
    while(*(DumpPtr - 1) != data);
}

/* Skip for n 4-bytes element */
void Sim_DumpSkip(uint16_t n)
{
    DumpPtr += n;
}

/* Stop the simulation */
void Sim_Stop(void)
{
    SIM_STOP_ADDR = 0;
}

/* Simple delay loop */
void Sim_Delay(uint32_t count)
{
    while(count--);
}

