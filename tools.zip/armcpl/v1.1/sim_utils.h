
#ifndef SIM_UTILS_H_
#define SIM_UTILS_H_

/* Standard libraries */
#include <stdint.h>

#define SIM_STOP_ADDR           (*(uint32_t *)0x07f00000)
#define MEM_DUMP_AREA_ADDR      0x04000000
#define MEM_DUMP_AREA_LENGTH    0x400

extern volatile uint32_t * DumpPtr;
extern void Sim_Dump(uint32_t data);
extern void Sim_DumpAdd(uint32_t data);
extern void Sim_DumpAll(void);
extern void Sim_DumpCheck(uint32_t data);
extern void Sim_DumpSkip(uint16_t n);
extern void Sim_Stop(void);
extern void Sim_Delay(uint32_t count);

#endif
