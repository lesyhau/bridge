
/* Standard libraries */
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>

#include "sim_utils.h"

volatile uint32_t * DumpPtr = (volatile uint32_t *)MEM_DUMP_AREA_ADDR;
uint32_t dumpArray[256];
uint16_t dumpArrayIndex;
//bool dumpArrayInit;

/* Write 4-bytes data out to BSC */
void Sim_Dump(uint32_t data)
{
    *DumpPtr = data;
    DumpPtr += 1;
}

/* Add 4-bytes element into dump array */
void Sim_DumpAdd(uint32_t data)
{
    //if (!dumpArrayInit)
    //{
    //    dumpArray = (uint32_t *)malloc(MEM_DUMP_AREA_LENGTH);
    //    dumpArrayIndex = 0;
    //    dumpArrayInit = true;
    //}

    dumpArray[dumpArrayIndex++] = data;
}

/* Write all 4-butes elements from dump array out to BSC */
void Sim_DumpAll(void)
{
    uint16_t j;
    
    for (j = 0; j < dumpArrayIndex; j++)
    {
        Sim_Dump(dumpArray[j]);
    }
}

/* Write 4-bytes data out to BSC and wait until the data is written */
void Sim_DumpCheck(uint32_t data)
{
    Sim_Dump(data);
    while(*(DumpPtr - 1) != data);
}

/* Skip for n 4-bytes element */
void Sim_DumpSkip(uint16_t n)
{
    dumpArrayIndex += n;
}

/* Stop the simulation */
void Sim_Stop(void)
{
    SIM_STOP_ADDR = 0;
}

/* Simple delay loop */
void Sim_Delay(uint32_t count)
{
    while(count--);
}

