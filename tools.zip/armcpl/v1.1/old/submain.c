
extern void el2_mpu_init(void);
extern void $Super$$main(void);

void $Sub$$main(void)
{
    el2_mpu_init();
    $Super$$main();
}

