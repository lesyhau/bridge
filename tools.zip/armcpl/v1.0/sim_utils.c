
/* Standard libraries */
#include <stdint.h>

#include "sim_utils.h"

volatile uint32_t * DumpPtr = (volatile uint32_t *)MEM_DUMP_AREA_ADDR;

void Sim_Dump(uint32_t data)
{
    *DumpPtr = data;
    DumpPtr += 1;
}

void Sim_CheckDump(uint32_t data)
{
    while(*DumpPtr != data);
}

void Sim_Stop(void)
{
    SIM_STOP_ADDR = 0;
}

void Sim_Delay(uint32_t count)
{
    while(count--);
}

